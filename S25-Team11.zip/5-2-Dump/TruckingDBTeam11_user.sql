CREATE DATABASE  IF NOT EXISTS `TruckingDBTeam11` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `TruckingDBTeam11`;
-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: cpsc4911.cobd8enwsupz.us-east-1.rds.amazonaws.com    Database: TruckingDBTeam11
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `UserID` int NOT NULL AUTO_INCREMENT,
  `Email` varchar(30) NOT NULL,
  `Username` varchar(30) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `FName` varchar(30) NOT NULL,
  `LName` varchar(30) NOT NULL,
  `PhoneNumber` varchar(20) NOT NULL,
  PRIMARY KEY (`UserID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'jzshaw18@gmail.com','driver','scrypt:32768:8:1$8Z8ciyR5BRrl62rf$97be56e1f3f0cfb347e5e43f07344221f0e6074821d448bee8b925df0d9595724d272c0c520f6c427a74140a72aaa2c6193701ce8b433e9bc52fd6bf9d2a12b2','notbob','ross','8474084974'),(2,'jzshaw@clemson.edu','admin','scrypt:32768:8:1$vWPsopFPXnhYmPCZ$224ce8a76c27177b9379664a3b1f88ae64466ff4d50850d5d4b2f2a1b7cf4bbf9d5a9e8e85fd1fe0936cf6af4c7e6e120035fed6a0ae488de9882702aa504d41','james','shaw','8474788476'),(3,'jzshaw@g.clemson.edu','sponsor','scrypt:32768:8:1$MMMkw4fufeyMVmWW$914e35d2df5f96d2be866f25e70362d95cf1b0f0af530cb01331c29160504950c1678c3eac55e8c9c053c5b08022d82110f173c6bb8885384377d39c8114b66f','not','james','4784789484'),(4,'joe@clemson.edu','joe','scrypt:32768:8:1$r2c1ACIOJ0D9Dxxv$6db54693a9bc01903ec833afe561c8ca57de97ff122b3be6b9b30ea9add49fbb4057051069b0f39d7078ba543f86efbdc0db7f4f2f1dba4afbde5686f6e9dfde','joe','bob','8764637653');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`admin`@`%`*/ /*!50003 TRIGGER `user_after_insert` AFTER INSERT ON `user` FOR EACH ROW BEGIN
    INSERT INTO changeLog (table_name, action_type, record_id, new_values, changed_by)
    VALUES (
        'user', 'INSERT', NEW.UserID,
        CONCAT('Email:', NEW.Email, ',Username:', NEW.Username, ',FName:', NEW.FName, 
               ',LName:', NEW.LName, ',PhoneNumber:', NEW.PhoneNumber),
        USER()
    );
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`admin`@`%`*/ /*!50003 TRIGGER `user_after_update` AFTER UPDATE ON `user` FOR EACH ROW BEGIN
    DECLARE changed TEXT DEFAULT '';
    IF NEW.Email != OLD.Email THEN SET changed = CONCAT(changed, 'Email:', OLD.Email, '->', NEW.Email, ','); END IF;
    IF NEW.Username != OLD.Username THEN SET changed = CONCAT(changed, 'Username:', OLD.Username, '->', NEW.Username, ','); END IF;
    IF NEW.Password != OLD.Password THEN SET changed = CONCAT(changed, 'Password:CHANGED,'); END IF;
    IF NEW.FName != OLD.FName THEN SET changed = CONCAT(changed, 'FName:', OLD.FName, '->', NEW.FName, ','); END IF;
    IF NEW.LName != OLD.LName THEN SET changed = CONCAT(changed, 'LName:', OLD.LName, '->', NEW.LName, ','); END IF;
    IF NEW.PhoneNumber != OLD.PhoneNumber THEN SET changed = CONCAT(changed, 'PhoneNumber:', OLD.PhoneNumber, '->', NEW.PhoneNumber, ','); END IF;
    
    IF changed != '' THEN
        INSERT INTO changeLog (table_name, action_type, record_id, changed_fields, old_values, new_values, changed_by)
        VALUES ('user', 'UPDATE', NEW.UserID, changed, 
                CONCAT('Email:', OLD.Email, ',Username:', OLD.Username, ',FName:', OLD.FName, 
                       ',LName:', OLD.LName, ',PhoneNumber:', OLD.PhoneNumber),
                CONCAT('Email:', NEW.Email, ',Username:', NEW.Username, ',FName:', NEW.FName, 
                       ',LName:', NEW.LName, ',PhoneNumber:', NEW.PhoneNumber),
                USER());
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`admin`@`%`*/ /*!50003 TRIGGER `user_after_delete` AFTER DELETE ON `user` FOR EACH ROW BEGIN
    INSERT INTO changeLog (table_name, action_type, record_id, old_values, changed_by)
    VALUES ('user', 'DELETE', OLD.UserID,
            CONCAT('Email:', OLD.Email, ',Username:', OLD.Username, ',FName:', OLD.FName, 
                   ',LName:', OLD.LName, ',PhoneNumber:', OLD.PhoneNumber),
            USER());
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-02  6:47:32
