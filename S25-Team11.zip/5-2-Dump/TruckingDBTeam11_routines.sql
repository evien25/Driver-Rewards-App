CREATE DATABASE  IF NOT EXISTS `TruckingDBTeam11` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `TruckingDBTeam11`;
-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: cpsc4911.cobd8enwsupz.us-east-1.rds.amazonaws.com    Database: TruckingDBTeam11
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Temporary view structure for view `user_roles_view`
--

DROP TABLE IF EXISTS `user_roles_view`;
/*!50001 DROP VIEW IF EXISTS `user_roles_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `user_roles_view` AS SELECT 
 1 AS `UserID`,
 1 AS `Email`,
 1 AS `Username`,
 1 AS `FName`,
 1 AS `LName`,
 1 AS `PhoneNumber`,
 1 AS `Role`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `user_roles_view`
--

/*!50001 DROP VIEW IF EXISTS `user_roles_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`admin`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `user_roles_view` AS select `u`.`UserID` AS `UserID`,`u`.`Email` AS `Email`,`u`.`Username` AS `Username`,`u`.`FName` AS `FName`,`u`.`LName` AS `LName`,`u`.`PhoneNumber` AS `PhoneNumber`,(case when (`d`.`DriverID` is not null) then 'driver' when (`a`.`AdminID` is not null) then 'admin' when (`s`.`SponsorUserID` is not null) then 'sponsor' else 'User' end) AS `Role` from (((`user` `u` left join `driver` `d` on((`u`.`UserID` = `d`.`UserID`))) left join `admin` `a` on((`u`.`UserID` = `a`.`UserID`))) left join `sponsoruser` `s` on((`u`.`UserID` = `s`.`UserID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Dumping routines for database 'TruckingDBTeam11'
--
/*!50003 DROP PROCEDURE IF EXISTS `AddAdmin` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`admin`@`%` PROCEDURE `AddAdmin`(
    IN Email VARCHAR(30),
    IN Username VARCHAR(30),
    IN Password VARCHAR(225),
    IN FName VARCHAR(30),
    IN LName VARCHAR(30),
    IN PhoneNumber VARCHAR(20),
    IN AdminStatus VARCHAR(30),
    IN AdminLevel INT
)
BEGIN
    DECLARE newUserID INT;
    
    START TRANSACTION;
    
    INSERT INTO user (Email, Username, Password, FName, LName, PhoneNumber)
    VALUES (Email, Username, Password, FName, LName, PhoneNumber);
    
    SET newUserID = LAST_INSERT_ID();
    
    INSERT INTO admin (UserID, AdminLevel, AdminStatus)
    VALUES (newUserID, AdminLevel, AdminStatus);

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AddDriver` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`admin`@`%` PROCEDURE `AddDriver`(
    IN Email VARCHAR(30),
    IN Username VARCHAR(30),
    IN Password VARCHAR(225),
    IN FName VARCHAR(30),
    IN LName VARCHAR(30),
    IN PhoneNumber VARCHAR(20)

)
BEGIN
    DECLARE newUserID INT;
    
    START TRANSACTION;
    
    INSERT INTO user (Email, Username, Password, FName, LName, PhoneNumber)
    VALUES (Email, Username, Password, FName, LName, PhoneNumber);
    
    SET newUserID = LAST_INSERT_ID();
    
    INSERT INTO driver (UserID, PointBalance, OrganizationID)
    VALUES (newUserID, 0, NULL);

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AddSponsorUser` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`admin`@`%` PROCEDURE `AddSponsorUser`(
    IN Email VARCHAR(30),
    IN Username VARCHAR(30),
    IN Password VARCHAR(225),
    IN FName VARCHAR(30),
    IN LName VARCHAR(30),
    IN PhoneNumber VARCHAR(20),
    IN OrganizationID INT,
    IN Level INT
)
BEGIN
    DECLARE newUserID INT;
    
    START TRANSACTION;
    
    INSERT INTO user (Email, Username, Password, FName, LName, PhoneNumber)
    VALUES (Email, Username, Password, FName, LName, PhoneNumber);
    
    SET newUserID = LAST_INSERT_ID();
    
    INSERT INTO sponsoruser (UserID, Level, OrganizationID)
    VALUES (newUserID, Level, OrganizationID);

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AssignPoints` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`admin`@`%` PROCEDURE `AssignPoints`(
    IN DriverID INT,
    IN Date DATE,
    IN SponsorUserID INT,
    IN Points INT,
    IN Reason VARCHAR(30)
)
BEGIN
    START TRANSACTION;
    
    INSERT INTO transactions (DriverID, Date, SponsorUserID, Points, Reason)
    VALUES (DriverID, Date, SponsorUserID, Points, Reason);

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ChangeUserRole` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`admin`@`%` PROCEDURE `ChangeUserRole`(
    IN p_UserID INT,
    IN p_NewRole VARCHAR(10), -- 'driver', 'sponsor', or 'admin'
    IN p_OrganizationID INT, -- Required for driver and sponsor
    IN p_AdminLevel INT,       -- Required for admin
    IN p_AdminStatus VARCHAR(30) -- Required for admin
)
BEGIN
    -- Declare variables for checking existence
    DECLARE driver_exists INT;
    DECLARE admin_exists INT;
    DECLARE sponsor_exists INT;

    -- Check if the user exists
    IF NOT EXISTS (SELECT 1 FROM user WHERE UserID = p_UserID) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'User does not exist.';
    END IF;

    -- Check existing roles
    SELECT COUNT(*) INTO driver_exists FROM driver WHERE UserID = p_UserID;
    SELECT COUNT(*) INTO admin_exists FROM admin WHERE UserID = p_UserID;
    SELECT COUNT(*) INTO sponsor_exists FROM sponsoruser WHERE UserID = p_UserID;

    -- Remove from all roles
    IF driver_exists > 0 THEN
        DELETE FROM driver WHERE UserID = p_UserID;
    END IF;
    IF admin_exists > 0 THEN
        DELETE FROM admin WHERE UserID = p_UserID;
    END IF;
    IF sponsor_exists > 0 THEN
        DELETE FROM sponsoruser WHERE UserID = p_UserID;
    END IF;

    -- Add to the new role
    IF p_NewRole = 'driver' THEN
        IF p_OrganizationID IS NULL THEN
            SET p_OrganizationID = NULL;
        END IF;
        INSERT INTO driver (UserID, OrganizationID, PointBalance) VALUES (p_UserID, p_OrganizationID, 0); -- Initialize PointBalance
    ELSEIF p_NewRole = 'sponsor' THEN
        IF p_OrganizationID IS NULL THEN
            SET p_OrganizationID = NULL;
        END IF;
        INSERT INTO sponsoruser (UserID, OrganizationID, Level) VALUES (p_UserID, p_OrganizationID, 1); -- Initialize Level
    ELSEIF p_NewRole = 'admin' THEN
        IF p_AdminLevel IS NULL OR p_AdminStatus IS NULL THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'AdminLevel and AdminStatus are required for admin role.';
        END IF;
        INSERT INTO admin (UserID, AdminLevel, AdminStatus) VALUES (p_UserID, p_AdminLevel, p_AdminStatus);
    ELSE
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid role specified.  Use ''driver'', ''sponsor'', or ''admin''.';
    END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetLoginInfo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`admin`@`%` PROCEDURE `GetLoginInfo`(
    IN username VARCHAR(255)
)
BEGIN
	#INSERT INTO changeLog (table_name, action_type, record_id, changed_by, new_values)
    #VALUES ('user', 'SELECT', userId, USER(), 'Selected data');
    
	SELECT 
		u.UserID,
		u.Username,
		u.Password,
		CASE 
			WHEN a.UserID IS NOT NULL THEN 'admin'
			WHEN s.UserID IS NOT NULL THEN 'sponsoruser'
			WHEN d.UserID IS NOT NULL THEN 'driver'
			ELSE 'error'
		END AS Role
	FROM 
		user u
	LEFT JOIN 
		admin a ON u.UserID = a.UserID
	LEFT JOIN 
		sponsoruser s ON u.UserID = s.UserID
	LEFT JOIN 
		driver d ON u.UserID = d.UserID
	WHERE 
		u.Username = username
	Limit 1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetPoints` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`admin`@`%` PROCEDURE `GetPoints`(
    IN UserID INT
)
BEGIN
	SELECT
		d.PointBalance,
        o.OrganizationName
	FROM
		driver d
	LEFT JOIN
		organization o ON d.OrganizationID = o.OrganizationID
	WHERE
		d.UserID = UserID;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UpdateUserPassword` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`admin`@`%` PROCEDURE `UpdateUserPassword`(
	IN userEmail VARCHAR(255),
    IN newPassword VARCHAR(255)
)
BEGIN
	UPDATE user u
	JOIN (SELECT UserID FROM user WHERE Email = userEmail) temp
	ON u.UserID = temp.UserID
	SET u.Password = newPassword;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-02  6:47:42
