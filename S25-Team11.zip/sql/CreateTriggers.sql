DROP TRIGGER IF EXISTS update_driver_points;
DROP TRIGGER IF EXISTS user_after_insert;
DROP TRIGGER IF EXISTS user_after_update;
DROP TRIGGER IF EXISTS user_after_delete;
DROP TRIGGER IF EXISTS organization_after_insert;
DROP TRIGGER IF EXISTS organization_after_update;
DROP TRIGGER IF EXISTS organization_after_delete;
DROP TRIGGER IF EXISTS driver_after_insert;
DROP TRIGGER IF EXISTS driver_after_update;
DROP TRIGGER IF EXISTS driver_after_delete;
DROP TRIGGER IF EXISTS admin_after_insert;
DROP TRIGGER IF EXISTS admin_after_update;
DROP TRIGGER IF EXISTS admin_after_delete;
DROP TRIGGER IF EXISTS sponsoruser_after_insert;
DROP TRIGGER IF EXISTS sponsoruser_after_update;
DROP TRIGGER IF EXISTS sponsoruser_after_delete;
DROP TRIGGER IF EXISTS address_after_insert;
DROP TRIGGER IF EXISTS address_after_update;
DROP TRIGGER IF EXISTS address_after_delete;
DROP TRIGGER IF EXISTS transactions_after_insert;
DROP TRIGGER IF EXISTS transactions_after_update;
DROP TRIGGER IF EXISTS transactions_after_delete;
DROP TRIGGER IF EXISTS applications_after_insert;
DROP TRIGGER IF EXISTS applications_after_update;
DROP TRIGGER IF EXISTS applications_after_delete;
DROP TRIGGER IF EXISTS sprint_after_insert;
DROP TRIGGER IF EXISTS sprint_after_update;
DROP TRIGGER IF EXISTS sprint_after_delete;

DELIMITER //
CREATE TRIGGER update_driver_points
AFTER INSERT ON transactions
FOR EACH ROW
BEGIN
    -- Update the points in users table based on the new transaction
    -- Let's say each $1 in transaction amount = 1 point
    UPDATE driver
    SET PointBalance = PointBalance + NEW.Points
    WHERE DriverID = NEW.DriverID;
END//
DELIMITER ;

-- USER TABLE TRIGGERS
DELIMITER //
CREATE TRIGGER user_after_insert
AFTER INSERT ON user
FOR EACH ROW
BEGIN
    INSERT INTO changeLog (table_name, action_type, record_id, new_values, changed_by)
    VALUES (
        'user', 'INSERT', NEW.UserID,
        CONCAT('Email:', NEW.Email, ',Username:', NEW.Username, ',FName:', NEW.FName, 
               ',LName:', NEW.LName, ',PhoneNumber:', NEW.PhoneNumber),
        USER()
    );
END//

CREATE TRIGGER user_after_update
AFTER UPDATE ON user
FOR EACH ROW
BEGIN
    DECLARE changed TEXT DEFAULT '';
    IF NEW.Email != OLD.Email THEN SET changed = CONCAT(changed, 'Email:', OLD.Email, '->', NEW.Email, ','); END IF;
    IF NEW.Username != OLD.Username THEN SET changed = CONCAT(changed, 'Username:', OLD.Username, '->', NEW.Username, ','); END IF;
    IF NEW.Password != OLD.Password THEN SET changed = CONCAT(changed, 'Password:CHANGED,'); END IF;
    IF NEW.FName != OLD.FName THEN SET changed = CONCAT(changed, 'FName:', OLD.FName, '->', NEW.FName, ','); END IF;
    IF NEW.LName != OLD.LName THEN SET changed = CONCAT(changed, 'LName:', OLD.LName, '->', NEW.LName, ','); END IF;
    IF NEW.PhoneNumber != OLD.PhoneNumber THEN SET changed = CONCAT(changed, 'PhoneNumber:', OLD.PhoneNumber, '->', NEW.PhoneNumber, ','); END IF;
    
    IF changed != '' THEN
        INSERT INTO changeLog (table_name, action_type, record_id, changed_fields, old_values, new_values, changed_by)
        VALUES ('user', 'UPDATE', NEW.UserID, changed, 
                CONCAT('Email:', OLD.Email, ',Username:', OLD.Username, ',FName:', OLD.FName, 
                       ',LName:', OLD.LName, ',PhoneNumber:', OLD.PhoneNumber),
                CONCAT('Email:', NEW.Email, ',Username:', NEW.Username, ',FName:', NEW.FName, 
                       ',LName:', NEW.LName, ',PhoneNumber:', NEW.PhoneNumber),
                USER());
    END IF;
END//

CREATE TRIGGER user_after_delete
AFTER DELETE ON user
FOR EACH ROW
BEGIN
    INSERT INTO changeLog (table_name, action_type, record_id, old_values, changed_by)
    VALUES ('user', 'DELETE', OLD.UserID,
            CONCAT('Email:', OLD.Email, ',Username:', OLD.Username, ',FName:', OLD.FName, 
                   ',LName:', OLD.LName, ',PhoneNumber:', OLD.PhoneNumber),
            USER());
END//
DELIMITER ;

-- ORGANIZATION TABLE TRIGGERS
DELIMITER //
CREATE TRIGGER organization_after_insert
AFTER INSERT ON organization
FOR EACH ROW
BEGIN
    INSERT INTO changeLog (table_name, action_type, record_id, new_values, changed_by)
    VALUES ('organization', 'INSERT', NEW.OrganizationID,
            CONCAT('OrganizationName:', NEW.OrganizationName, ',Statement:', NEW.OrganizationStatement),
            USER());
END//

CREATE TRIGGER organization_after_update
AFTER UPDATE ON organization
FOR EACH ROW
BEGIN
    DECLARE changed TEXT DEFAULT '';
    IF NEW.OrganizationName != OLD.OrganizationName THEN SET changed = CONCAT(changed, 'OrganizationName:', OLD.OrganizationName, '->', NEW.OrganizationName, ','); END IF;
    IF NEW.OrganizationStatement != OLD.OrganizationStatement THEN SET changed = CONCAT(changed, 'Statement:', OLD.OrganizationStatement, '->', NEW.OrganizationStatement, ','); END IF;
    
    IF changed != '' THEN
        INSERT INTO changeLog (table_name, action_type, record_id, changed_fields, old_values, new_values, changed_by)
        VALUES ('organization', 'UPDATE', NEW.OrganizationID, changed,
                CONCAT('OrganizationName:', OLD.OrganizationName, ',Statement:', OLD.OrganizationStatement),
                CONCAT('OrganizationName:', NEW.OrganizationName, ',Statement:', NEW.OrganizationStatement),
                USER());
    END IF;
END//

CREATE TRIGGER organization_after_delete
AFTER DELETE ON organization
FOR EACH ROW
BEGIN
    INSERT INTO changeLog (table_name, action_type, record_id, old_values, changed_by)
    VALUES ('organization', 'DELETE', OLD.OrganizationID,
            CONCAT('OrganizationName:', OLD.OrganizationName, ',Statement:', OLD.OrganizationStatement),
            USER());
END//
DELIMITER ;

-- DRIVER TABLE TRIGGERS
DELIMITER //
CREATE TRIGGER driver_after_insert
AFTER INSERT ON driver
FOR EACH ROW
BEGIN
    INSERT INTO changeLog (table_name, action_type, record_id, new_values, changed_by)
    VALUES ('driver', 'INSERT', NEW.DriverID,
            CONCAT('UserID:', NEW.UserID, ',PointBalance:', NEW.PointBalance, ',OrganizationID:', NEW.OrganizationID),
            USER());
END//

CREATE TRIGGER driver_after_update
AFTER UPDATE ON driver
FOR EACH ROW
BEGIN
    DECLARE changed TEXT DEFAULT '';
    IF NEW.UserID != OLD.UserID THEN SET changed = CONCAT(changed, 'UserID:', OLD.UserID, '->', NEW.UserID, ','); END IF;
    IF NEW.PointBalance != OLD.PointBalance THEN SET changed = CONCAT(changed, 'PointBalance:', OLD.PointBalance, '->', NEW.PointBalance, ','); END IF;
    IF NEW.OrganizationID != OLD.OrganizationID THEN SET changed = CONCAT(changed, 'OrganizationID:', OLD.OrganizationID, '->', NEW.OrganizationID, ','); END IF;
    
    IF changed != '' THEN
        INSERT INTO changeLog (table_name, action_type, record_id, changed_fields, old_values, new_values, changed_by)
        VALUES ('driver', 'UPDATE', NEW.DriverID, changed,
                CONCAT('UserID:', OLD.UserID, ',PointBalance:', OLD.PointBalance, ',OrganizationID:', OLD.OrganizationID),
                CONCAT('UserID:', NEW.UserID, ',PointBalance:', NEW.PointBalance, ',OrganizationID:', NEW.OrganizationID),
                USER());
    END IF;
END//

CREATE TRIGGER driver_after_delete
AFTER DELETE ON driver
FOR EACH ROW
BEGIN
    INSERT INTO changeLog (table_name, action_type, record_id, old_values, changed_by)
    VALUES ('driver', 'DELETE', OLD.DriverID,
            CONCAT('UserID:', OLD.UserID, ',PointBalance:', OLD.PointBalance, ',OrganizationID:', OLD.OrganizationID),
            USER());
END//
DELIMITER ;

-- ADMIN TABLE TRIGGERS
DELIMITER //
CREATE TRIGGER admin_after_insert
AFTER INSERT ON admin
FOR EACH ROW
BEGIN
    INSERT INTO changeLog (table_name, action_type, record_id, new_values, changed_by)
    VALUES ('admin', 'INSERT', NEW.AdminID,
            CONCAT('AdminLevel:', NEW.AdminLevel, ',AdminStatus:', NEW.AdminStatus, ',UserID:', NEW.UserID),
            USER());
END//

CREATE TRIGGER admin_after_update
AFTER UPDATE ON admin
FOR EACH ROW
BEGIN
    DECLARE changed TEXT DEFAULT '';
    IF NEW.AdminLevel != OLD.AdminLevel THEN SET changed = CONCAT(changed, 'AdminLevel:', OLD.AdminLevel, '->', NEW.AdminLevel, ','); END IF;
    IF NEW.AdminStatus != OLD.AdminStatus THEN SET changed = CONCAT(changed, 'AdminStatus:', OLD.AdminStatus, '->', NEW.AdminStatus, ','); END IF;
    IF NEW.UserID != OLD.UserID THEN SET changed = CONCAT(changed, 'UserID:', OLD.UserID, '->', NEW.UserID, ','); END IF;
    
    IF changed != '' THEN
        INSERT INTO changeLog (table_name, action_type, record_id, changed_fields, old_values, new_values, changed_by)
        VALUES ('admin', 'UPDATE', NEW.AdminID, changed,
                CONCAT('AdminLevel:', OLD.AdminLevel, ',AdminStatus:', OLD.AdminStatus, ',UserID:', OLD.UserID),
                CONCAT('AdminLevel:', NEW.AdminLevel, ',AdminStatus:', NEW.AdminStatus, ',UserID:', NEW.UserID),
                USER());
    END IF;
END//

CREATE TRIGGER admin_after_delete
AFTER DELETE ON admin
FOR EACH ROW
BEGIN
    INSERT INTO changeLog (table_name, action_type, record_id, old_values, changed_by)
    VALUES ('admin', 'DELETE', OLD.AdminID,
            CONCAT('AdminLevel:', OLD.AdminLevel, ',AdminStatus:', OLD.AdminStatus, ',UserID:', OLD.UserID),
            USER());
END//
DELIMITER ;

-- SPONSORUSER TABLE TRIGGERS
DELIMITER //
CREATE TRIGGER sponsoruser_after_insert
AFTER INSERT ON sponsoruser
FOR EACH ROW
BEGIN
    INSERT INTO changeLog (table_name, action_type, record_id, new_values, changed_by)
    VALUES ('sponsoruser', 'INSERT', NEW.SponsorUserID,
            CONCAT('OrganizationID:', NEW.OrganizationID, ',Level:', NEW.Level, ',UserID:', NEW.UserID),
            USER());
END//

CREATE TRIGGER sponsoruser_after_update
AFTER UPDATE ON sponsoruser
FOR EACH ROW
BEGIN
    DECLARE changed TEXT DEFAULT '';
    IF NEW.OrganizationID != OLD.OrganizationID THEN SET changed = CONCAT(changed, 'OrganizationID:', OLD.OrganizationID, '->', NEW.OrganizationID, ','); END IF;
    IF NEW.Level != OLD.Level THEN SET changed = CONCAT(changed, 'Level:', OLD.Level, '->', NEW.Level, ','); END IF;
    IF NEW.UserID != OLD.UserID THEN SET changed = CONCAT(changed, 'UserID:', OLD.UserID, '->', NEW.UserID, ','); END IF;
    
    IF changed != '' THEN
        INSERT INTO changeLog (table_name, action_type, record_id, changed_fields, old_values, new_values, changed_by)
        VALUES ('sponsoruser', 'UPDATE', NEW.SponsorUserID, changed,
                CONCAT('OrganizationID:', OLD.OrganizationID, ',Level:', OLD.Level, ',UserID:', OLD.UserID),
                CONCAT('OrganizationID:', NEW.OrganizationID, ',Level:', NEW.Level, ',UserID:', NEW.UserID),
                USER());
    END IF;
END//

CREATE TRIGGER sponsoruser_after_delete
AFTER DELETE ON sponsoruser
FOR EACH ROW
BEGIN
    INSERT INTO changeLog (table_name, action_type, record_id, old_values, changed_by)
    VALUES ('sponsoruser', 'DELETE', OLD.SponsorUserID,
            CONCAT('OrganizationID:', OLD.OrganizationID, ',Level:', OLD.Level, ',UserID:', OLD.UserID),
            USER());
END//
DELIMITER ;

-- ADDRESS TABLE TRIGGERS
DELIMITER //
CREATE TRIGGER address_after_insert
AFTER INSERT ON address
FOR EACH ROW
BEGIN
    INSERT INTO changeLog (table_name, action_type, record_id, new_values, changed_by)
    VALUES ('address', 'INSERT', NEW.AddressID,
            CONCAT('Street:', NEW.Street, ',Apt:', NEW.Apt, ',City:', NEW.City, 
                   ',State:', NEW.State, ',Country:', NEW.Country, ',Zipcode:', NEW.Zipcode, ',UserID:', NEW.UserID),
            USER());
END//

CREATE TRIGGER address_after_update
AFTER UPDATE ON address
FOR EACH ROW
BEGIN
    DECLARE changed TEXT DEFAULT '';
    IF NEW.Street != OLD.Street THEN SET changed = CONCAT(changed, 'Street:', OLD.Street, '->', NEW.Street, ','); END IF;
    IF NEW.Apt != OLD.Apt THEN SET changed = CONCAT(changed, 'Apt:', OLD.Apt, '->', NEW.Apt, ','); END IF;
    IF NEW.City != OLD.City THEN SET changed = CONCAT(changed, 'City:', OLD.City, '->', NEW.City, ','); END IF;
    IF NEW.State != OLD.State THEN SET changed = CONCAT(changed, 'State:', OLD.State, '->', NEW.State, ','); END IF;
    IF NEW.Country != OLD.Country THEN SET changed = CONCAT(changed, 'Country:', OLD.Country, '->', NEW.Country, ','); END IF;
    IF NEW.Zipcode != OLD.Zipcode THEN SET changed = CONCAT(changed, 'Zipcode:', OLD.Zipcode, '->', NEW.Zipcode, ','); END IF;
    IF NEW.UserID != OLD.UserID THEN SET changed = CONCAT(changed, 'UserID:', OLD.UserID, '->', NEW.UserID, ','); END IF;
    
    IF changed != '' THEN
        INSERT INTO changeLog (table_name, action_type, record_id, changed_fields, old_values, new_values, changed_by)
        VALUES ('address', 'UPDATE', NEW.AddressID, changed,
                CONCAT('Street:', OLD.Street, ',Apt:', OLD.Apt, ',City:', OLD.City, 
                       ',State:', OLD.State, ',Country:', OLD.Country, ',Zipcode:', OLD.Zipcode, ',UserID:', OLD.UserID),
                CONCAT('Street:', NEW.Street, ',Apt:', NEW.Apt, ',City:', NEW.City, 
                       ',State:', NEW.State, ',Country:', NEW.Country, ',Zipcode:', NEW.Zipcode, ',UserID:', NEW.UserID),
                USER());
    END IF;
END//

CREATE TRIGGER address_after_delete
AFTER DELETE ON address
FOR EACH ROW
BEGIN
    INSERT INTO changeLog (table_name, action_type, record_id, old_values, changed_by)
    VALUES ('address', 'DELETE', OLD.AddressID,
            CONCAT('Street:', OLD.Street, ',Apt:', OLD.Apt, ',City:', OLD.City, 
                   ',State:', OLD.State, ',Country:', OLD.Country, ',Zipcode:', OLD.Zipcode, ',UserID:', OLD.UserID),
            USER());
END//
DELIMITER ;

-- TRANSACTIONS TABLE TRIGGERS
DELIMITER //
CREATE TRIGGER transactions_after_insert
AFTER INSERT ON transactions
FOR EACH ROW
BEGIN
    INSERT INTO changeLog (table_name, action_type, record_id, new_values, changed_by)
    VALUES ('transactions', 'INSERT', NEW.TransactionID,
            CONCAT('DriverID:', NEW.DriverID, ',Date:', NEW.Date, ',SponsorUserID:', NEW.SponsorUserID, 
                   ',Points:', NEW.Points, ',Reason:', NEW.Reason),
            USER());
END//

CREATE TRIGGER transactions_after_update
AFTER UPDATE ON transactions
FOR EACH ROW
BEGIN
    DECLARE changed TEXT DEFAULT '';
    IF NEW.DriverID != OLD.DriverID THEN SET changed = CONCAT(changed, 'DriverID:', OLD.DriverID, '->', NEW.DriverID, ','); END IF;
    IF NEW.Date != OLD.Date THEN SET changed = CONCAT(changed, 'Date:', OLD.Date, '->', NEW.Date, ','); END IF;
    IF NEW.SponsorUserID != OLD.SponsorUserID THEN SET changed = CONCAT(changed, 'SponsorUserID:', OLD.SponsorUserID, '->', NEW.SponsorUserID, ','); END IF;
    IF NEW.Points != OLD.Points THEN SET changed = CONCAT(changed, 'Points:', OLD.Points, '->', NEW.Points, ','); END IF;
    IF NEW.Reason != OLD.Reason THEN SET changed = CONCAT(changed, 'Reason:', OLD.Reason, '->', NEW.Reason, ','); END IF;
    
    IF changed != '' THEN
        INSERT INTO changeLog (table_name, action_type, record_id, changed_fields, old_values, new_values, changed_by)
        VALUES ('transactions', 'UPDATE', NEW.TransactionID, changed,
                CONCAT('DriverID:', OLD.DriverID, ',Date:', OLD.Date, ',SponsorUserID:', OLD.SponsorUserID, 
                       ',Points:', OLD.Points, ',Reason:', OLD.Reason),
                CONCAT('DriverID:', NEW.DriverID, ',Date:', NEW.Date, ',SponsorUserID:', NEW.SponsorUserID, 
                       ',Points:', NEW.Points, ',Reason:', NEW.Reason),
                USER());
    END IF;
END//

CREATE TRIGGER transactions_after_delete
AFTER DELETE ON transactions
FOR EACH ROW
BEGIN
    INSERT INTO changeLog (table_name, action_type, record_id, old_values, changed_by)
    VALUES ('transactions', 'DELETE', OLD.TransactionID,
            CONCAT('DriverID:', OLD.DriverID, ',Date:', OLD.Date, ',SponsorUserID:', OLD.SponsorUserID, 
                   ',Points:', OLD.Points, ',Reason:', OLD.Reason),
            USER());
END//
DELIMITER ;

-- APPLICATIONS TABLE TRIGGERS
DELIMITER //
CREATE TRIGGER applications_after_insert
AFTER INSERT ON applications
FOR EACH ROW
BEGIN
    INSERT INTO changeLog (table_name, action_type, record_id, new_values, changed_by)
    VALUES ('applications', 'INSERT', NEW.ApplicationID,
            CONCAT('DriverID:', NEW.DriverID, ',OrganizationID:', NEW.OrganizationID, ',Description:', NEW.Description),
            USER());
END//

CREATE TRIGGER applications_after_update
AFTER UPDATE ON applications
FOR EACH ROW
BEGIN
    DECLARE changed TEXT DEFAULT '';
    IF NEW.DriverID != OLD.DriverID THEN SET changed = CONCAT(changed, 'DriverID:', OLD.DriverID, '->', NEW.DriverID, ','); END IF;
    IF NEW.OrganizationID != OLD.OrganizationID THEN SET changed = CONCAT(changed, 'OrganizationID:', OLD.OrganizationID, '->', NEW.OrganizationID, ','); END IF;
    IF NEW.Description != OLD.Description THEN SET changed = CONCAT(changed, 'Description:', OLD.Description, '->', NEW.Description, ','); END IF;
    
    IF changed != '' THEN
        INSERT INTO changeLog (table_name, action_type, record_id, changed_fields, old_values, new_values, changed_by)
        VALUES ('applications', 'UPDATE', NEW.ApplicationID, changed,
                CONCAT('DriverID:', OLD.DriverID, ',OrganizationID:', OLD.OrganizationID, ',Description:', OLD.Description),
                CONCAT('DriverID:', NEW.DriverID, ',OrganizationID:', NEW.OrganizationID, ',Description:', NEW.Description),
                USER());
    END IF;
END//

CREATE TRIGGER applications_after_delete
AFTER DELETE ON applications
FOR EACH ROW
BEGIN
    INSERT INTO changeLog (table_name, action_type, record_id, old_values, changed_by)
    VALUES ('applications', 'DELETE', OLD.ApplicationID,
            CONCAT('DriverID:', OLD.DriverID, ',OrganizationID:', OLD.OrganizationID, ',Description:', OLD.Description),
            USER());
END//
DELIMITER ;

-- SPRINT TABLE TRIGGERS
DELIMITER //
CREATE TRIGGER sprint_after_insert
AFTER INSERT ON sprint
FOR EACH ROW
BEGIN
    INSERT INTO changeLog (table_name, action_type, record_id, new_values, changed_by)
    VALUES ('sprint', 'INSERT', NEW.Team, -- Using Team as record_id since there's no explicit ID
            CONCAT('Team:', NEW.Team, ',Version:', NEW.Version, ',ReleaseDate:', NEW.ReleaseDate, 
                   ',ProductName:', NEW.ProductName, ',ProductDescription:', NEW.ProductDescription),
            USER());
END//

CREATE TRIGGER sprint_after_update
AFTER UPDATE ON sprint
FOR EACH ROW
BEGIN
    DECLARE changed TEXT DEFAULT '';
    IF NEW.Team != OLD.Team THEN SET changed = CONCAT(changed, 'Team:', OLD.Team, '->', NEW.Team, ','); END IF;
    IF NEW.Version != OLD.Version THEN SET changed = CONCAT(changed, 'Version:', OLD.Version, '->', NEW.Version, ','); END IF;
    IF NEW.ReleaseDate != OLD.ReleaseDate THEN SET changed = CONCAT(changed, 'ReleaseDate:', OLD.ReleaseDate, '->', NEW.ReleaseDate, ','); END IF;
    IF NEW.ProductName != OLD.ProductName THEN SET changed = CONCAT(changed, 'ProductName:', OLD.ProductName, '->', NEW.ProductName, ','); END IF;
    IF NEW.ProductDescription != OLD.ProductDescription THEN SET changed = CONCAT(changed, 'ProductDescription:', OLD.ProductDescription, '->', NEW.ProductDescription, ','); END IF;
    
    IF changed != '' THEN
        INSERT INTO changeLog (table_name, action_type, record_id, changed_fields, old_values, new_values, changed_by)
        VALUES ('sprint', 'UPDATE', NEW.Team, changed,
                CONCAT('Team:', OLD.Team, ',Version:', OLD.Version, ',ReleaseDate:', OLD.ReleaseDate, 
                       ',ProductName:', OLD.ProductName, ',ProductDescription:', OLD.ProductDescription),
                CONCAT('Team:', NEW.Team, ',Version:', NEW.Version, ',ReleaseDate:', NEW.ReleaseDate, 
                       ',ProductName:', NEW.ProductName, ',ProductDescription:', NEW.ProductDescription),
                USER());
    END IF;
END//

CREATE TRIGGER sprint_after_delete
AFTER DELETE ON sprint
FOR EACH ROW
BEGIN
    INSERT INTO changeLog (table_name, action_type, record_id, old_values, changed_by)
    VALUES ('sprint', 'DELETE', OLD.Team,
            CONCAT('Team:', OLD.Team, ',Version:', OLD.Version, ',ReleaseDate:', OLD.ReleaseDate, 
                   ',ProductName:', OLD.ProductName, ',ProductDescription:', OLD.ProductDescription),
            USER());
END//
DELIMITER ;

