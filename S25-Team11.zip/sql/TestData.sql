USE TruckingDBTeam11;
INSERT INTO user (Username, Email, Password, FName, LName, PhoneNumber)
VALUES ('zbuddy', 'jzshaw@clemson.edu', 'hello', 'Zachary', 'Shaw', '8646343274');
INSERT INTO user (Username, Email, Password, FName, LName, PhoneNumber)
VALUES ('jzshaw', 'jzshaw18@gmail.com', 'password', 'James', 'Shaw', '8648675309');
INSERT INTO sprint
VALUES ('11', '1', '2025-02-6', 'Driver App', 'Enable points tracking and rewards for drivers');
INSERT INTO sprint
VALUES ('11', '2', '2025-02-13', 'Driver App', 'Enable points tracking and rewards for drivers');
INSERT INTO sprint
VALUES ('11', '3', '2025-02-20', 'Driver App', 'Enable points tracking and rewards for drivers');
INSERT INTO sprint
VALUES ('11', '4', '2025-02-27', 'Driver App', 'Enable points tracking and rewards for drivers');
INSERT INTO sprint
VALUES ('11', '5', '2025-03-6', 'Driver App', 'Enable points tracking and rewards for drivers');
INSERT INTO sprint
VALUES ('11', '6', '2025-03-13', 'Driver App', 'Enable points tracking and rewards for drivers');
INSERT INTO sprint
VALUES ('11', '7', '2025-03-20', 'Driver App', 'Enable points tracking and rewards for drivers');
INSERT INTO sprint
VALUES ('11', '10', '2025-04-17', 'Driver App', 'Enable points tracking and rewards for drivers');
INSERT INTO address (Street, City, State, Country, Zipcode, UserID)
VALUES ('525A Eastview Dr', 'Pendleton', 'SC', 'USA', 29670, 1);
INSERT INTO address (Street, City, State, Country, Zipcode, UserID)
VALUES ('400 Lakeview Dr', 'Seneca', 'SC', 'USA', 29678, 2);
INSERT INTO organization (OrganizationName, OrganizationStatement)
VALUES ('Trucking Team 2', 'Bad Team');
Call AddDriver('jzshaw18@gmail.com',
     'driver',
     'driver' ,
     'James' ,
     'Shaw' ,
     '8645555555',
     1);
Call AddSponsorUser('jzshaw@gmail.com',
     'zbuddy18',
     'nobody' ,
     'James' ,
     'Shaw' ,
     '8645555555' ,
     1,
     1);
Call AddAdmin('jzshaw@gmail.com',
     'zbuddy17',
     'lol' ,
     'zach' ,
     'naw' ,
     '8645555595' ,
     'Active',
     1);
Call AssignPoints(
	1,
    '2025-02-14',
    1,
    5000,
    'good job');
    

