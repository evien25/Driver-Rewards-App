DROP SCHEMA IF EXISTS TruckingDBTeam11;
CREATE SCHEMA TruckingDBTeam11;
USE TruckingDBTeam11;

CREATE TABLE user (
	UserID INT AUTO_INCREMENT,
    Email VARCHAR(30) NOT NULL,
    Username VARCHAR(30) NOT NULL,
    Password VARCHAR(255) NOT NULL,
    FName VARCHAR(30) NOT NULL,
    LName VARCHAR(30) NOT NULL,
    PhoneNumber VARCHAR(20) NOT NULL,
    PRIMARY KEY (UserID)
);

CREATE TABLE organization (
	OrganizationID INT AUTO_INCREMENT,
    OrganizationName VARCHAR(30) NOT NULL,
    OrganizationStatement VARCHAR(30),
	PRIMARY KEY (OrganizationID)
);

CREATE TABLE driver (
	DriverID INT AUTO_INCREMENT,
    UserID INT,
    PointBalance INT,
    OrganizationID INT,
    PRIMARY KEY (DriverID),
    FOREIGN KEY (UserID) REFERENCES user(UserID) ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (OrganizationID) REFERENCES organization(OrganizationID) ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE admin (
	AdminID INT AUTO_INCREMENT,
    AdminLevel INT,
    AdminStatus VARCHAR(30),
    UserID INT,
    PRIMARY KEY (AdminID),
    FOREIGN KEY (UserID) REFERENCES user(UserID) ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE sponsoruser (
	SponsorUserID INT AUTO_INCREMENT,
    OrganizationID INT,
    Level INT,
    UserID INT,
    PRIMARY KEY (SponsorUserID),
    FOREIGN KEY (UserID) REFERENCES user(UserID) ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (OrganizationID) REFERENCES organization(OrganizationID) ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE address (
	AddressID INT AUTO_INCREMENT,
    Street VARCHAR(30),
    Apt VARCHAR(30),
    City VARCHAR(30),
    State VARCHAR(30),
    Country VARCHAR(30),
    Zipcode INT,
    UserID INT,
    PRIMARY KEY (AddressID),
    FOREIGN KEY (UserID) REFERENCES user(UserID) ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE transactions (
	TransactionID INT AUTO_INCREMENT,
    DriverID INT,
    Date DATE,
    SponsorUserID INT,
    Points INT,
    Reason VARCHAR(30),
    PRIMARY KEY (TransactionID),
    FOREIGN KEY (DriverID) REFERENCES driver(DriverID) ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (SponsorUserID) REFERENCES user(UserID) ON UPDATE CASCADE ON DELETE CASCADE
);


CREATE TABLE applications (
	ApplicationID INT AUTO_INCREMENT,
    UserID INT,
    OrganizationID INT,
    Description VARCHAR (1000),
    PRIMARY KEY (ApplicationID),
    FOREIGN KEY (OrganizationID) REFERENCES organization(OrganizationID) ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (UserID) REFERENCES user(UserID) ON UPDATE CASCADE ON DELETE CASCADE
);

DROP TABLE sprint;
CREATE TABLE sprint (
	Team INT,
    Version INT,
    ReleaseDate DATE,
    ProductName VARCHAR(30),
    ProductDescription VARCHAR(100)
);

CREATE TABLE changeLog (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    table_name VARCHAR(100) NOT NULL,
    action_type ENUM('INSERT', 'UPDATE', 'DELETE') NOT NULL,
    record_id INT NOT NULL,
    changed_fields TEXT,
    old_values TEXT,
    new_values TEXT,
    changed_by VARCHAR(100),
    change_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS passreset (
	email VARCHAR(100),
    token INT,
    date DATETIME
);

CREATE TABLE catalog (
    CatalogItemID INT AUTO_INCREMENT PRIMARY KEY,
    OrganizationID INT NOT NULL,
    eBayItemID VARCHAR(50) NOT NULL,
    Title VARCHAR(255),
    Price VARCHAR(50),
    ImageURL TEXT,
    DateAdded TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    AddedBySponsorID INT,
    Inventory INT DEFAULT 1
);

CREATE TABLE IF NOT EXISTS driver_purchases (
    PurchaseID INT AUTO_INCREMENT PRIMARY KEY,
    DriverID INT,
    Items JSON,
    PurchaseDate DATETIME DEFAULT NOW()
);