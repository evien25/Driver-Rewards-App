DROP PROCEDURE IF EXISTS AddDriver;
DROP PROCEDURE IF EXISTS AddSponsorUser;
DROP PROCEDURE IF EXISTS AddAdmin;
DROP PROCEDURE IF EXISTS AssignPoints;
DROP PROCEDURE IF EXISTS GetLoginInfo;
DROP PROCEDURE IF EXISTS GetPoints;
DROP PROCEDURE IF EXISTS UpdateUserPassword;
DROP PROCEDURE IF EXISTS ChangeUserRole;
# add driver address procedure
DELIMITER //
CREATE PROCEDURE AddDriver(
    IN Email VARCHAR(30),
    IN Username VARCHAR(30),
    IN Password VARCHAR(225),
    IN FName VARCHAR(30),
    IN LName VARCHAR(30),
    IN PhoneNumber VARCHAR(20)

)
BEGIN
    DECLARE newUserID INT;
    
    START TRANSACTION;
    
    INSERT INTO user (Email, Username, Password, FName, LName, PhoneNumber)
    VALUES (Email, Username, Password, FName, LName, PhoneNumber);
    
    SET newUserID = LAST_INSERT_ID();
    
    INSERT INTO driver (UserID, PointBalance, OrganizationID)
    VALUES (newUserID, 0, NULL);

    COMMIT;
END//
DELIMITER ;

DELIMITER //
CREATE PROCEDURE AddSponsorUser(
    IN Email VARCHAR(30),
    IN Username VARCHAR(30),
    IN Password VARCHAR(30),
    IN FName VARCHAR(30),
    IN LName VARCHAR(30),
    IN PhoneNumber VARCHAR(20),
    IN OrganizationID INT,
    IN Level INT
)
BEGIN
    DECLARE newUserID INT;
    
    START TRANSACTION;
    
    INSERT INTO user (Email, Username, Password, FName, LName, PhoneNumber)
    VALUES (Email, Username, Password, FName, LName, PhoneNumber);
    
    SET newUserID = LAST_INSERT_ID();
    
    INSERT INTO sponsoruser (UserID, Level, OrganizationID)
    VALUES (newUserID, Level, OrganizationID);

    COMMIT;
END//
DELIMITER ;

DELIMITER //
CREATE PROCEDURE AddAdmin(
    IN Email VARCHAR(30),
    IN Username VARCHAR(30),
    IN Password VARCHAR(30),
    IN FName VARCHAR(30),
    IN LName VARCHAR(30),
    IN PhoneNumber VARCHAR(20),
    IN AdminStatus VARCHAR(30),
    IN AdminLevel INT
)
BEGIN
    DECLARE newUserID INT;
    
    START TRANSACTION;
    
    INSERT INTO user (Email, Username, Password, FName, LName, PhoneNumber)
    VALUES (Email, Username, Password, FName, LName, PhoneNumber);
    
    SET newUserID = LAST_INSERT_ID();
    
    INSERT INTO admin (UserID, AdminLevel, AdminStatus)
    VALUES (newUserID, AdminLevel, AdminStatus);

    COMMIT;
END//
DELIMITER ;

DELIMITER //
CREATE PROCEDURE AssignPoints(
    IN DriverID INT,
    IN Date DATE,
    IN SponsorUserID INT,
    IN Points INT,
    IN Reason VARCHAR(30)
)
BEGIN
    START TRANSACTION;
    
    INSERT INTO transactions (DriverID, Date, SponsorUserID, Points, Reason)
    VALUES (DriverID, Date, SponsorUserID, Points, Reason);

    COMMIT;
END//
DELIMITER ;

DELIMITER //

CREATE PROCEDURE GetLoginInfo(
    IN username VARCHAR(255)
)
BEGIN
	#INSERT INTO changeLog (table_name, action_type, record_id, changed_by, new_values)
    #VALUES ('user', 'SELECT', userId, USER(), 'Selected data');
    
	SELECT 
		u.UserID,
		u.Username,
		u.Password,
		CASE 
			WHEN a.UserID IS NOT NULL THEN 'admin'
			WHEN s.UserID IS NOT NULL THEN 'sponsoruser'
			WHEN d.UserID IS NOT NULL THEN 'driver'
			ELSE 'error'
		END AS Role
	FROM 
		user u
	LEFT JOIN 
		admin a ON u.UserID = a.UserID
	LEFT JOIN 
		sponsoruser s ON u.UserID = s.UserID
	LEFT JOIN 
		driver d ON u.UserID = d.UserID
	WHERE 
		u.Username = username
	Limit 1;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE GetPoints(
    IN UserID INT
)
BEGIN
	SELECT
		d.PointBalance,
        o.OrganizationName
	FROM
		driver d
	LEFT JOIN
		organization o ON d.OrganizationID = o.OrganizationID
	WHERE
		d.UserID = UserID;
END //
DELIMITER ;

DELIMITER //

CREATE PROCEDURE UpdateUserPassword(
	IN userEmail VARCHAR(255),
    IN newPassword VARCHAR(255)
)
BEGIN
	UPDATE user u
	JOIN (SELECT UserID FROM user WHERE Email = userEmail) temp
	ON u.UserID = temp.UserID
	SET u.Password = newPassword;
END//
DELIMITER ;

DELIMITER //
CREATE PROCEDURE ChangeUserRole(
    IN p_UserID INT,
    IN p_NewRole VARCHAR(10), -- 'driver', 'sponsor', or 'admin'
    IN p_OrganizationID INT, -- Required for driver and sponsor
    IN p_AdminLevel INT,       -- Required for admin
    IN p_AdminStatus VARCHAR(30) -- Required for admin
)
BEGIN
    -- Declare variables for checking existence
    DECLARE driver_exists INT;
    DECLARE admin_exists INT;
    DECLARE sponsor_exists INT;

    -- Check if the user exists
    IF NOT EXISTS (SELECT 1 FROM user WHERE UserID = p_UserID) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'User does not exist.';
    END IF;

    -- Check existing roles
    SELECT COUNT(*) INTO driver_exists FROM driver WHERE UserID = p_UserID;
    SELECT COUNT(*) INTO admin_exists FROM admin WHERE UserID = p_UserID;
    SELECT COUNT(*) INTO sponsor_exists FROM sponsoruser WHERE UserID = p_UserID;

    -- Remove from all roles
    IF driver_exists > 0 THEN
        DELETE FROM driver WHERE UserID = p_UserID;
    END IF;
    IF admin_exists > 0 THEN
        DELETE FROM admin WHERE UserID = p_UserID;
    END IF;
    IF sponsor_exists > 0 THEN
        DELETE FROM sponsoruser WHERE UserID = p_UserID;
    END IF;

    -- Add to the new role
    IF p_NewRole = 'driver' THEN
        IF p_OrganizationID IS NULL THEN
            SET p_OrganizationID = NULL;
        END IF;
        INSERT INTO driver (UserID, OrganizationID, PointBalance) VALUES (p_UserID, p_OrganizationID, 0); -- Initialize PointBalance
    ELSEIF p_NewRole = 'sponsor' THEN
        IF p_OrganizationID IS NULL THEN
            SET p_OrganizationID = NULL;
        END IF;
        INSERT INTO sponsoruser (UserID, OrganizationID, Level) VALUES (p_UserID, p_OrganizationID, 1); -- Initialize Level
    ELSEIF p_NewRole = 'admin' THEN
        IF p_AdminLevel IS NULL OR p_AdminStatus IS NULL THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'AdminLevel and AdminStatus are required for admin role.';
        END IF;
        INSERT INTO admin (UserID, AdminLevel, AdminStatus) VALUES (p_UserID, p_AdminLevel, p_AdminStatus);
    ELSE
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid role specified.  Use ''driver'', ''sponsor'', or ''admin''.';
    END IF;

END //
DELIMITER ;
