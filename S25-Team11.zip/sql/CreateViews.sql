DROP VIEW IF EXISTS user_roles_view;
CREATE VIEW user_roles_view AS
SELECT
    u.UserID,
    u.Email,
    u.Username,
    u.FName,
    u.LName,
    u.PhoneNumber,
    CASE
        WHEN d.DriverID IS NOT NULL THEN 'driver'
        WHEN a.AdminID IS NOT NULL THEN 'admin'
        WHEN s.SponsorUserID IS NOT NULL THEN 'sponsor'
        ELSE 'User' -- Default role if not found in other tables
    END AS Role
FROM
    user u
LEFT JOIN
    driver d ON u.UserID = d.UserID
LEFT JOIN
    admin a ON u.UserID = a.UserID
LEFT JOIN
    sponsoruser s ON u.UserID = s.UserID;
