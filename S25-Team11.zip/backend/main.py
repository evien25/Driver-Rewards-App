from flask import Flask, jsonify, Response, request
from flask_mail import Mail, Message
import random
from flask_cors import CORS
from modules.dbconnect import dbconnector
import json
import os
import requests
from dotenv import load_dotenv
import mysql.connector
import csv
import jwt
import datetime
from io import StringIO
from werkzeug.security import check_password_hash
from werkzeug.security import generate_password_hash

load_dotenv(dotenv_path=os.getcwd()+"/data/.env")


app = Flask(__name__)
# app.config['SECRET_KEY'] = 'your-secret-key'  # Used for key hash
CORS(app, resources={r"/api/*": {"origins": "https://web.11.pandanas.net"}})

# Environment variables for database credentials
db_host = os.environ.get("DB_HOST1")
db_user = os.environ.get("DB_USER1")
db_password = os.environ.get("DB_PASSWORD1")
db_name = os.environ.get("DB_NAME1")
secret_key = os.environ.get("SECRET_KEY")
mail_server = os.environ.get("MAIL_SERVER")
mail_port = os.environ.get("MAIL_PORT")
mail_tls = os.environ.get("MAIL_TLS")
mail_username = os.environ.get("MAIL_USERNAME")
mail_password = os.environ.get("MAIL_PASSWORD")

app.config['SECRET_KEY'] = secret_key
app.config['MAIL_SERVER'] = mail_server
app.config['MAIL_PORT'] = mail_port
app.config['MAIL_USE_TLS'] = mail_tls
app.config['MAIL_USERNAME'] = mail_username
app.config['MAIL_PASSWORD'] = mail_password

mail = Mail(app)

print(f"Host: {db_host}, User: {db_user}, Pass: {db_password}, Name: {db_name}")
BASE64_AUTH = "Basic RXJpY1ZpZW4tUzI1VGVhbTEtUFJELTA2OGNhZTg0OS01YmJmYmM5NjpQUkQtNjhjYWU4NDkzODRkLTExMTUtNGIzYy1iNjgxLTY0Zjk="

# Initialize db connection
dbConfig = {
    'host':db_host,
    'user':db_user,
    'password':db_password,
    'database':db_name
}
db = dbconnector(dbConfig)
db.init_app(app)

# sprint 4 token verification trial?
def verify_token(token):
    try:
        decoded = jwt.decode(token, app.config['SECRET_KEY'], algorithms=['HS256'])
        return decoded['user_id']
    except jwt.ExpiredSignatureError:
        return None
    except jwt.InvalidTokenError:
        return None

# Used to set the data directory for environment variables and json
with open(os.getcwd()+'/data/about.json', 'r') as file:
    aboutData = json.load(file)
#print(f"Json read {aboutData}")

# Testing with react
@app.route('/api/about')
def about():
    # Pass the json to React
    return aboutData

# sprint 4/5 profile route
@app.route('/api/profile', methods=['GET', 'PUT'])
def profile():
    try:
        if request.method == 'GET':
            UserID = request.headers.get('Authorization').split(' ')[1] # get userid from authorization header
            command = "SELECT username, FName, LName, Email, PhoneNumber FROM user WHERE UserID = %s"
            profileData = db.fetchQueryOne(command, (UserID,)) # issues
            content = {'username': profileData[0], 'FName': profileData[1], 'LName': profileData[2], 'Email': profileData[3], 'PhoneNumber': profileData[4], 'UserID': UserID}
            return jsonify(content)
        elif request.method == 'PUT':
            data = request.get_json()
            print(data)
            mydb = mysql.connector.connect(
                host=db_host,
                user=db_user,
                password=db_password,
                database=db_name
            )
            cursor = mydb.cursor()
            cursor.execute("UPDATE user SET FName = %s, LName = %s, Email = %s, PhoneNumber = %s WHERE UserID = %s", (data["FName"],data["LName"],data["Email"],data["PhoneNumber"],data["UserID"],))
            mydb.commit()
            mydb.close()
            print(cursor.rowcount, "record(s) affected")
            return jsonify({'message': 'Profile updated successfully'})
    except Exception as e:
        print(e)
        return jsonify({'message': 'Database error'}), 500
    
@app.route('/api/address', methods=['GET', 'PUT'])
def address():
    try:
        if request.method == 'GET':
            UserID = request.headers.get('Authorization').split(' ')[1] # get userid from authorization header
            command = "SELECT Street, Apt, City, State, Country, Zipcode FROM address WHERE UserID = %s"
            addressData = db.fetchQueryOne(command, (UserID,))
            #print(addressData)
            if addressData != 0:
                content = {'Street': addressData[0], 'Apt': addressData[1], 'City': addressData[2], 'State': addressData[3], 'Country': addressData[4], 'Zipcode': addressData[5], 'UserID': UserID}
                return jsonify(content)
            else:
                return jsonify({'Street': '', 'Apt': '', 'City': '', 'State': '', 'Country': '', 'Zipcode': '', 'Country': '', 'UserID': ''}
)
        elif request.method == 'PUT': #work on this part
            data = request.get_json()
            print(data)
            command = "UPDATE address SET Street = %s, Apt = %s , City = %s, State = %s, Country = %s, Zipcode = %s WHERE UserID = %s"
            statement = db.executeQuery(command, (data["Street"],data["Apt"],data["City"],data["State"],data["Country"],data["Zipcode"],data["userId"],))
            print(statement)
            if statement != 0:
                return jsonify({'message': 'Address updated successfully'})
            else:
                print("attempting to insert address")
                command = "INSERT INTO address (Street, Apt, City, State, Country, Zipcode, UserID) VALUES (%s, %s, %s, %s, %s, %s, %s)"
                db.executeQuery(command, (data["Street"],data["Apt"],data["City"],data["State"],data["Country"],data["Zipcode"],data["userId"]))
                return jsonify({'message': 'Address created successfully'})
    except Exception as e:
        print(e)
        return jsonify({'message': 'Database error'}), 500

# sprint 3
@app.route('/api/sprint_data')
def sprint():
    command = "SELECT Team, Version, ReleaseDate, ProductName, ProductDescription FROM sprint"
    results = db.fetchQuery(command)
    print(results)
    sprint_list = []
    for row in results:
        sprint_data = {
            "Team": row[0],
            "Version": row[1],
            "ReleaseDate": row[2],
            "ProductName": row[3],
            "ProductDescription": row[4]
        }
        sprint_list.append(sprint_data)
    return jsonify(sprint_list)

@app.route('/api/mysql/status')
def status():
    if db.checkStatus:
        response_data = {"status": "Connected"}
    else:
        response_data = {"status": "Unable to connect"}
    print(f"Response: {response_data}")
    return jsonify(response_data), 200
    

@app.route('/api/login', methods=['POST'])
def login():
    data = request.get_json()  # Get JSON data sent from React
    username = data.get('username')
    password = data.get('password')
    #print(f'user: {username} pass: {password}')
    command = "Call GetLoginInfo(%s)"
    results = db.fetchQueryOne(command, (username,))
    #print(results[2])
    if results and check_password_hash(results[2], password): #compare hashed passwords
        #check the tables for user type
        role = results[3]
        userid = results[0]
        if (role == 'sponsoruser') :
            command = "SELECT SponsoruserID FROM sponsoruser WHERE UserID = '{userid}'"
            results = db.fetchQuery(command)
            driverID = results
        elif ((role == 'admin')) :
            command = "SELECT AdminID FROM admin WHERE UserID = '{userid}'"
            results = db.fetchQuery(command)
            driverID = results
        else:
            command = "SELECT DriverID FROM driver WHERE UserID = '{userid}'"
            results = db.fetchQuery(command)
            driverID = results
        return jsonify({'success': True, 'userid': userid, 'role': role , 'driverID' : driverID}), 200 # 200 OK
    else:
      return jsonify({'success': False, 'message': 'Invalid credentials'}), 401 # 401 Unauthorized

@app.route('/api/points', methods=['GET'])
def points():
    try:
        userID = request.headers.get('Authorization').split(' ')[1]
        #print(userID)
        command = "Call GetPoints(%s)"
        results = db.fetchQuery(command, (int(userID),))
        points_list = []
        for row in results:
            points_data = {
                "Points": row[0],
                "Organization": row[1],
            }
            points_list.append(points_data)
        return jsonify(points_list)
    except Exception as e:
        return jsonify({"message": str(e)}), 500
    
@app.route('/api/report', methods=['GET'])
def reports():
    try:
        command = "SELECT table_name, action_type, changed_fields, old_values, new_values, changed_by, change_timestamp FROM changeLog"
        results = db.fetchQuery(command)
        records = []
        for row in results:
            record_list = {
                "Table" : row[0],
                "Action" : row[1],
                "FieldChanged" : row[2],
                "OldValue" : row[3],
                "NewValue" : row[4],
                "Changedby" : row[5],
                "Timestamp" : row[6],
            }
            records.append(record_list)
        return jsonify(records)
    except Exception as e:
        return jsonify({"message": str(e)}), 500
    
@app.route('/api/report/download')
def download_records():
    try:
        command = ("SELECT * FROM changeLog")
        records = db.fetchQueryDict(command)
        
        # Create CSV in memory
        si = StringIO()
        csv_writer = csv.writer(si)
        
        # Write header
        if records:
            csv_writer.writerow(records[0].keys())
            # Write data rows
            for row in records:
                csv_writer.writerow(row.values())
        
        # Create response
        output = si.getvalue()
        return Response(
            output,
            mimetype="text/csv",
            headers={"Content-Disposition": "attachment;filename=records.csv"}
        )
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/AccRegister' , methods=['POST'])
def AccRegister():
    data = request.get_json()
    print(data.get('username'))
    command = f"SELECT Username FROM user WHERE Username = '{data.get('username')}'"
    
    results = db.fetchQuery(command)
    print(results)
    if (not results):
        print("entered not results")
        #hashing the password before storing it 
        hashed_password = generate_password_hash(data.get('password'))
        insertUser = ("CALL AddDriver(%s , %s , %s , %s , %s , %s)")
        Username = data.get('username')
        Password = hashed_password
        Email = data.get('email')
        FName = data.get('FName')
        LName = data.get('LName')
        Phonenumber = data.get('phonenumber')

        db.executeQuery(insertUser , (Email , Username , Password , FName , LName , Phonenumber))
        command = f"SELECT UserID FROM user WHERE Username = '{Username}'"
        results = db.fetchQuery(command)
        UserID = results[0][0]
        print(UserID)
        
        return jsonify({'success': True , 'userid' : UserID}) , 200 #success created driver
    else :
        print("entered else")
        return jsonify({'success': False}) , 401 #username already exists
    
    # "as a user, i can change my password"
    # NOT for forgotten password changes

@app.route('/api/SpsApp' , methods=['POST'])
def SpsApp():
    data = request.get_json()

    postType = data.get('currPost')

    if (postType == "1") :
        UserID = data.get('userID')

        command = "SELECT OrganizationID from driver WHERE UserID = %s"
        DriverOrgs = db.fetchQuery(command , (UserID,))

        command = "SELECT OrganizationID , OrganizationName from organization"
        orgs = db.fetchQuery(command)

        results = []

        if (DriverOrgs is None) :
            for i in orgs:
                list = {
                    'Name': i[1],
                    'orgID': i[0]
                }
                results.append(list)
        else :
            for i in orgs:
                addOrg = True
                for j in DriverOrgs:
                    if (i[0] == j[0]) :
                        addOrg = False
                if (addOrg) :
                    list = {
                        'Name': i[1],
                        'orgID': i[0]
                    }
                    results.append(list)

        return jsonify(results)
    elif (postType == "2") :
        userID = data.get('userID')
        OrganizationID = data.get('OrgID')
        Description = data.get('description')
        print("entered not results")
        insertUser = "INSERT INTO applications (UserID , OrganizationID , Description) VALUES (%s , %s , %s)"
        
        db.executeQuery(insertUser , (userID , OrganizationID , Description))
        return jsonify({'success': True}) , 200 #success created driver
    else :
        print("entered else")
        return jsonify({'success': False}) , 401 #username already exists

@app.route('/api/SpsPoints', methods=['POST'])
def SpsPoints():
    data = request.get_json()
    postType = data.get('currPost')
    print(postType)

    if (postType == "1"):
        print("got Here 1")
        OrgID = data.get('orgID')
        command = f"SELECT UserID , DriverID , PointBalance FROM driver WHERE OrganizationID = '{OrgID}'"
        pointResults = db.fetchQuery(command)
        print(pointResults)
        userResults = []
        for i in pointResults:
            command = f"SELECT FName , LName FROM user WHERE UserId = '{i[0]}'"
            user = db.fetchQuery(command)
            userList = {
                'FirstName' : user[0][0] ,
                'LastName' : user[0][1] ,
                'driverID' : i[1] ,
                'pointBalance' : i[2]
                
            }
            userResults.append(userList)
        return jsonify(userResults)
    elif (postType == "2"):
        print("got Here 2")
        OrgID = data.get('orgID')
        command = f"SELECT UserID , Description FROM applications WHERE OrganizationID = '{OrgID}'"
        pointResults = db.fetchQuery(command)

        userResults = []

        print("point Results =" , pointResults)

        for i in pointResults:
            print("driver =" , i[0])
            command = f"SELECT FName , LName FROM user WHERE UserId = '{i[0]}'"
            user = db.fetchQuery(command)
            print("user =" , user)
            userList = {
                'FirstName' : user[0][0] ,
                'LastName' : user[0][1] ,
                'Description' : i[1] ,
                'UserID' : i[0]
            }
            userResults.append(userList)

            print(userResults)
        
        return jsonify(userResults)
    elif (postType == "3"):
        print("got Here 3")
        data = request.get_json()
        DriverID = data.get('driverID')
        Points = data.get('balance')
        currDate = datetime.datetime.now()
        sponsorID = data.get('spsUserID')
        reason = data.get('reason')

        negative = data.get('positive')

        if (negative == "Negative") :
            Points = Points * -1

        print(Points)
        command = "CALL AssignPoints(%s , %s , %s , %s , %s)"
        db.executeQuery(command , (DriverID , currDate , sponsorID , Points , reason))

        return jsonify({'success': True}), 200 # 200 OK

    elif (postType == "4"):
        print("got Here 4")
        data = request.get_json()

        DriverID = data.get('DriverID')
        OrgID = data.get('orgID')
        Decision = data.get('decision')
        DUserID = data.get('driverUserID')


        if (Decision == "Accept"):
            command = "INSERT INTO driver (UserID , PointBalance , OrganizationID) VALUES (%s , %s , %s)"
            db.executeQuery(command , (DUserID , 0 , OrgID))

            command = "DELETE FROM applications WHERE UserID = %s"
            db.executeQuery(command , (DUserID,))

            return jsonify({'success': True}), 200 # 200 OK

        elif(Decision == "Deny"):
            print("entered Deny")

            command = "DELETE FROM applications WHERE UserID = %s"
            db.executeQuery(command , (DUserID,))
            return jsonify({'success': True}), 200 # 200 OK

        return jsonify({'success': True}), 200 # 200 OK
    else:
        return jsonify({'success': False,}), 400 # 401 Unauthorized

@app.route('/api/reset-password', methods=['POST'])
def reset_password():
    data = request.get_json() #Get JSON data sent from React 
    token = data.get('token')
    new_password = data.get('newPassword')
    print(token)
    print(new_password)

    # Fetch the current password hash from the database
    command = "SELECT email FROM passreset WHERE token = %s"
    email = db.fetchQueryOne(command, (token,))
    
    print(email[0])
    if email:
        # Hash the new password
        hashed_new_password = generate_password_hash(new_password)
        print(hashed_new_password)
        
        # Update the password in the database
        update_command = "CALL UpdateUserPassword(%s, %s)"
        db.executeQuery(update_command, (email[0], hashed_new_password))
        
        return jsonify({'success': True, 'message': 'Password updated successfully'}), 200
    else:
        return jsonify({'success': False, 'message': 'Old password is incorrect'}), 401
    
@app.route('/api/request-password-reset', methods=['POST'])
def request_password_reset():
    data = request.get_json()
    email = data.get('email')
    command = "SELECT * from user WHERE Email = %s"
    result = db.fetchQueryOne(command, (email,))
    #print(result)
    # If the email exist in the db
    if result:
        # Generate reset token
        reset_token = str(random.randint(0, 999999)).zfill(6)
        
        # Send email
        msg = Message('Password Reset Request',
                    sender="jzshaw13@gmail.com",
                    recipients=[email])
        msg.html = f"""
            <html>
            <body style="font-family: Arial, sans-serif; background-color: #f9f9f9; padding: 20px;">
                <div style="max-width: 500px; margin: auto; background: white; padding: 20px; border-radius: 10px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                <h2 style="color: #333;">Password Reset Request</h2>
                <p>Hello,</p>
                <p>You recently requested to reset your password. Use the code below to continue:</p>
                <div style="font-size: 24px; font-weight: bold; letter-spacing: 4px; background: #f0f0f0; padding: 15px; text-align: center; border-radius: 5px; margin: 20px 0;">
                    {reset_token}
                </div>
                <p>If you did not request a password reset, you can safely ignore this email.</p>
                <p style="margin-top: 30px;">Thanks,<br>The Trucking Team</p>
                </div>
            </body>
            </html>
            """
        mail.send(msg)

        command2 = "INSERT INTO passreset (email, token, date) VALUES (%s, %s, %s)"
        current = datetime.datetime.now()
        test = db.executeQuery(command2, (email, int(reset_token), current))

        return jsonify({'message': 'Reset email sent'}), 200
    
    return jsonify({'message': 'Account with email does not exist'}), 401



@app.route('/api/ebay/token', methods=['POST'])
def get_ebay_token():
    url = "https://api.ebay.com/identity/v1/oauth2/token"

    headers = {
        'Authorization': BASE64_AUTH,
        'Content-Type': 'application/x-www-form-urlencoded'
    }
    payload = {
        'grant_type': 'client_credentials',
        'scope': 'https://api.ebay.com/oauth/api_scope'
    }

    print(f"Sending request to: {url}") # logging for testing
    print(f"Headers: {headers}")
    print(f"Payload: {payload}")

    try:
        response = requests.post(url, headers=headers, data=payload)
        print(f"Response Status Code: {response.status_code}")
        print(f"Response Content: {response.text}")

        if response.status_code == 200:
            token_data = response.json()
            return jsonify(token_data), 200 # token create success

        else:
            try:
                error_data = response.json()
            except ValueError:
                error_data = {'message': response.text}
                return jsonify({'error': error_data}), response.status_code

    except Exception as e:
        print(f"Exception: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/ebay/search', methods=['GET'])
def search_ebay():
    query = request.args.get("q", "")
    if not query:
        return jsonify({"error": "Missing search query"}), 400

    token_response = requests.post(
        "https://api.ebay.com/identity/v1/oauth2/token",
        headers={
            'Authorization': BASE64_AUTH,
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        data={
            'grant_type': 'client_credentials',
            'scope': 'https://api.ebay.com/oauth/api_scope'
        }
    )

    if token_response.status_code != 200:
        return jsonify({"error": "Failed to get eBay token"}), 500

    access_token = token_response.json().get("access_token")
    if not access_token:
        return jsonify({"error": "eBay token error"}), 500

    search_url = f"https://api.ebay.com/buy/browse/v1/item_summary/search?q={query}&limit=10"
    headers = {
        "Authorization": f"Bearer {access_token}", # used bearer auth, worked on postman
        "Content-Type": "application/json"
    }

    try:
        ebay_response = requests.get(search_url, headers=headers)
        return jsonify(ebay_response.json()), ebay_response.status_code
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    
@app.route('/api/sponsor-info/<int:user_id>', methods=['GET'])
def get_sponsor_info(user_id):
    try:
        command = "SELECT SponsorUserID, OrganizationID FROM sponsoruser WHERE UserID = %s"
        result = db.fetchQueryOne(command, (user_id,))
        if result:
            return jsonify({
                "sponsor_user_id": result[0],
                "organization_id": result[1]
            }), 200
        else:
            return jsonify({"error": "Sponsor info not found"}), 404
    except Exception as e:
        print("Get sponsor info error:", e)
        return jsonify({"error": str(e)}), 500

@app.route('/api/catalog', methods=['POST'])
def add_catalog_item():
    try:
        data = request.get_json()
        print("Recieved catalog data:", data)
        command = "INSERT INTO catalog (OrganizationID, eBayItemID, Title, Price, ImageURL, AddedBySponsorID) VALUES (%s, %s, %s, %s, %s, %s)"
        params = (
            data['organization_id'],
            data['ebay_id'],
            data['title'],
            data['price'],
            data['image'],
            data['sponsor_user_id']
        )
        db.executeQuery(command, params)
        return jsonify({"message": "Added to catalog successfully"}), 201
    except Exception as e:
        print("Catalog additoin error:", e)
        return jsonify({"error": str(e)}), 500
        
@app.route('/api/catalog/<int:org_id>', methods=['GET'])
def get_catalog_by_org(org_id):
    try:
        command = "SELECT CatalogItemID, eBayItemID, Title, Price, ImageURL, DateAdded, Inventory FROM catalog WHERE OrganizationID = %s"
        results = db.fetchQueryDict(command, (org_id,))
        return jsonify(results), 200
    except Exception as e:
        print("Get catalog error:", e)
        return jsonify({"error": str(e)}), 500

@app.route('/api/catalog/delete/<int:item_id>', methods=['DELETE'])
def delete_catalog_item(item_id):
    try:
        command = "DELETE FROM catalog WHERE CatalogItemID = %s"
        db.executeQuery(command, (item_id,))
        return jsonify({"message": "Item deleted"}), 200
    except Exception as e:
        print("Delete item error:", e)
        return jsonify({"error": str(e)}), 500

@app.route('/api/catalog/update-inventory/<int:item_id>', methods=['POST'])
def update_inventory(item_id):
    try:
        data = request.get_json()
        update_inventory = data.get('inventory')

        command = "UPDATE catalog SET Inventory = %s WHERE CatalogItemID = %s"
        db.executeQuery(command, (update_inventory, item_id))

        return jsonify({"message": "Inventory updated"}), 200
    except Exception as e:
        print("Update inventory error:", e)
        return jsonify({"error": str(e)}), 500

@app.route('/api/driver-info/<int:user_id>', methods=['GET'])
def get_driver_info(user_id):
    try:
        command = "SELECT DriverID, OrganizationID, PointBalance FROM driver WHERE UserID = %s Limit 1"
        result = db.fetchQueryOne(command, (user_id,))
        if result:
            return jsonify({
                "driver_user_id": result[0],
                "organization_id": result[1],
                "point_balance": result[2]
            }), 200
        else:
            return jsonify({"error": "Driver info not found"}), 404
    except Exception as e:
        print("Get driver info error:", e)
        return jsonify({"error": str(e)}), 500

@app.route('/api/checkout', methods=['POST'])
def checkout():
    try:
        data = request.get_json()
        driver_id = data.get("driver_id")
        items = data.get("items")

        # calculate total cost of cart
        total_cost = 0
        for item in items:
            price_str = item["Price"].split()[0]
            price = float(price_str)
            quantity = item["quantity"]
            total_cost += price * quantity

        # fetch current point balance
        result = db.fetchQueryOne("SELECT PointBalance FROM driver WHERE DriverID = %s", (driver_id,))
        if not result:
            return jsonify({"error": "Driver not found"}), 404

        current_points = result[0]
        if total_cost > current_points:
            return jsonify({"error": "Insufficient funds"}), 404

        # deduct points from user
        db.executeQuery(
            "UPDATE driver SET PointBalance = PointBalance - %s WHERE DriverID = %s",
            (total_cost, driver_id)
        )

        # update inventory
        for item in items:
            catalog_id = item["CatalogItemID"]
            quantity = item["quantity"]

            # update inventory for each item based on cart
            update_query = "UPDATE catalog SET Inventory = Inventory - %s WHERE CatalogItemID = %s AND Inventory >= %s"
            db.executeQuery(update_query, (quantity, catalog_id, quantity))

        # save purchased cart into driver purchase history table
        insert_query = "INSERT INTO driver_purchases (DriverID, Items) VALUES (%s, %s)"
        db.executeQuery(insert_query, (driver_id, json.dumps(items))) # json dumps used to pass json array of items into single table

        return jsonify({
            "message": "Checkout successful!",
            "points_remaining": current_points - total_cost
        }), 200

    except Exception as e:
        print("Checkout error:", e)
        return jsonify({"error": str(e)}), 500

@app.route('/api/purchase-history/<int:driver_id>', methods=['GET'])
def get_purchase_history(driver_id):
    try:
        query = "SELECT PurchaseID, Items, PurchaseDate FROM driver_purchases WHERE DriverID = %s ORDER BY PurchaseDate DESC"
        results = db.fetchQueryDict(query, (driver_id,))
        return jsonify(results), 200
    except Exception as e:
        print("Error fetching purchase history:", e)
        return jsonify({"error": str(e)}), 500

@app.route('/api/usertable')
def display_users():
    try:
        command = ("SELECT * FROM user_roles_view")
        records = db.fetchQueryDict(command)
        
        return jsonify(records)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/user/role/<int:user_id>', methods=['PUT'])
def update_user_role(user_id):
    try:
        data = request.get_json()
        new_role = data.get('role')

        # Validate the new role
        if not new_role in ('driver', 'sponsor', 'admin'):
            return jsonify({'error': 'Invalid role.  Must be "driver", "sponsor", or "admin".'}), 400

        # Get additional parameters from the request, default to None if not provided
        organization_id = ''
        admin_level = 0
        admin_status = 'active'

        #cursor.callproc('ChangeUserRole', (user_id, new_role, organization_id, admin_level, admin_status))
        update_command = "CALL ChangeUserRole(%s, %s. %s, %s, %s)"
        db.executeQuery(update_command, (user_id, new_role, organization_id, admin_level, admin_status))

        return jsonify({'message': 'User role updated successfully'}), 200

    except Exception as e:
        print(f"Error updating user role: {e}")
        return jsonify({'message': 'Internal server error'}), 500

@app.route('/api/DriverSponsors' , methods=['POST'])
def DriverSponsors():
    data = request.get_json()
    postType = data.get('currPost')
    if (postType == "1"):
        #get current sponsors
        return
    elif (postType == "2"):
        #get application status
        return
    else:
        return

if __name__ == "__main__":
    # used for dev
    app.run(host="0.0.0.0", debug=False, port=5000)
    # used for docker
    #app.run()
