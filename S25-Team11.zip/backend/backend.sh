#/bin/bash
cd backend
source ./testing/bin/activate
python3 main.py
