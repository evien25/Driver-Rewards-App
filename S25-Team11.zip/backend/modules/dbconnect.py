import mysql.connector
from mysql.connector import Error
from flask import g, Flask

class dbconnector:
    def __init__(self, config):
        """Initialize a single database connection."""
        self.config = config
        self.conn = None
        self.app = None  # Hold Flask App Instance

    def init_app(self, app: Flask):
        """
        Initialize the db connector with the flask app instance.
        This is crucial for using teardown_appcontext
        """
        self.app = app
        app.teardown_appcontext(self.close_db)  # Register close_db

    def get_db(self):
        """Get or create a single database connection."""
        if 'db_conn' not in g or not g.db_conn.is_connected():
            try:
                if not self.conn or not self.conn.is_connected():
                    self.conn = mysql.connector.connect(**self.config)
                g.db_conn = self.conn
            except Error as e:
                print(f"Error getting connection: {e}")
                raise  # Re-raise the exception for Flask to handle
        return g.db_conn

    def close_db(self, e=None):
        """Close the connection if it exists."""
        db = g.pop('db_conn', None)
        if db and db.is_connected():
            db.close()
            self.conn = None

    def _execute_query(self, query, params=None, fetch=False, dictionary=False, one=False, max_retries=3):
        """
        Internal method to handle query execution with retry logic and flexible fetching.

        Args:
            query (str): The SQL query to execute.
            params (tuple, optional): Parameters to pass to the query. Defaults to None.
            fetch (bool, optional): Whether to fetch results. Defaults to False.
            dictionary (bool, optional): Whether to fetch results as dictionaries. Defaults to False.
            one (bool, optional): Whether to fetch only one result. Defaults to False
            max_retries (int, optional): Maximum number of retries. Defaults to 3.

        Returns:
            mixed: Depends on the query and fetch parameters.
        """
        conn = self.get_db()
        for attempt in range(1, max_retries + 1):
            cursor = None
            try:
                cursor = conn.cursor(dictionary=dictionary)
                cursor.execute(query, params or ())
                if fetch:
                    if one:
                        results = cursor.fetchone()
                        return results if results else None  # consistent return of None
                    else:
                        results = cursor.fetchall()
                        return results
                else:
                    conn.commit()
                    return cursor.rowcount
            except Error as e:
                print(f"Error executing query (attempt {attempt}/{max_retries}): {e}")
                if attempt < max_retries:
                    # Reconnect before retrying
                    if conn.is_connected():
                        conn.close()
                    self.conn = None
                    conn = self.get_db()
                    continue  # Retry the query
                else:
                    raise  # Re-raise the exception after max retries
            finally:
                if cursor:
                    cursor.close()

    def executeQuery(self, query, params=None, max_retries=3):
        """Execute a non-fetching query (INSERT, UPDATE, DELETE)."""
        return self._execute_query(query, params, fetch=False, max_retries=max_retries)

    def fetchQuery(self, query, params=None, max_retries=3):
        """Execute a fetching query (SELECT) and return all rows."""
        return self._execute_query(query, params, fetch=True, max_retries=max_retries)

    def fetchQueryDict(self, query, params=None, max_retries=3):
        """Execute a fetching query (SELECT) and return all rows as dictionaries."""
        return self._execute_query(query, params, fetch=True, dictionary=True, max_retries=max_retries)

    def fetchQueryOne(self, query, params=None, max_retries=3):
        """Execute a fetching query (SELECT) and return one row."""
        return self._execute_query(query, params, fetch=True, one=True, max_retries=max_retries)

    def checkStatus(self, max_retries=3):
        """Check the database connection status."""
        conn = self.get_db()  # Acquire connection
        for attempt in range(1, max_retries + 1):
            try:
                if conn.is_connected():
                    return True
                else:
                    return False
            except Error as e:
                print(f"Error checking connection (attempt {attempt}/{max_retries}): {e}")
                if attempt < max_retries:
                    continue
                else:
                    return False
        return False