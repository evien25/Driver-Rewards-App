#/bin/bash
cd frontend && ./frontend.sh &
cd backend && ./backend.sh &
wait

