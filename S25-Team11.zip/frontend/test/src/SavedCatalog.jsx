import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Catalog.css";
import DriverCatalog from './DriverCatalog';

const SavedCatalog = () => {
    const [savedItems, setSavedItems] = useState([]);
    const [editedInventory, setEditedInventory] = useState({});
    const [viewAsDriver, setViewAsDriver] = useState(false);
    const navigate = useNavigate();

    const fetchCatalog = async () => {
        const organization_id = parseInt(localStorage.getItem("organization_id"));
        if (!organization_id) return;

        try {
            const response = await fetch(`${process.env.REACT_APP_API_URL}/api/catalog/${organization_id}`);
            const data = await response.json();
            if (!response.ok) throw new Error(data.error);
            setSavedItems(data);
        } catch (error) {
            console.error("Error loading catalog:", error);
        }
    };

    useEffect(() => {
        fetchCatalog();
    }, []);

const removeItem = async (itemId) => {
    try {
        const response = await fetch(`${process.env.REACT_APP_API_URL}/api/catalog/delete/${itemId}`, {
            method: "DELETE"
        });
        const data = await response.json();
        if (!response.ok) throw new Error(data.error);

        setSavedItems(prev => prev.filter(item => item.CatalogItemID !== itemId)); // current array (prev) = previous array with item with itemId
    } catch (error) {
        console.error("Error deleting item:", error);
    }
};

const updateInventory = async (itemId, newInventory) => {
    try {
        const response = await fetch(`${process.env.REACT_APP_API_URL}/api/catalog/update-inventory/${itemId}`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ inventory: newInventory })
        });

        const data = await response.json();
        if (!response.ok) throw new Error(data.error);

        setSavedItems(prev => prev.map(item => item.CatalogItemID === itemId ? { ...item, Inventory: newInventory } : item )); // loops through current list, finds item then updates inventory
        
        fetchCatalog();
        setEditedInventory(prev => {
            const updated = { ...prev };
            delete updated[itemId];
            return updated;
        });

    } catch (error) {
        console.error("Error updating inventory:", error);
    }
};

const handleInventoryInput = (itemId, value) => {
    setEditedInventory(prev => ({ ...prev, [itemId]: value })); // holds current
};

const handleInventorySave = (itemId) => {
    const newValue = parseInt(editedInventory[itemId], 10); // needed or else json error is thrown
    if (!isNaN(newValue) && newValue >= 0) {
        updateInventory(itemId, newValue);
    }
};

if (viewAsDriver) {
    return (
        <div>
            <button className="back-btn" onClick={() => setViewAsDriver(false)}>← Back to Sponsor View</button>
            <DriverCatalog />
        </div>
    );
}

    return (
        <div className="catalog-container">
            <button className="cancel-btn" onClick={() => navigate("/catalog")}>Back to Catalog</button>
            <button className="create-btn" onClick={() => setViewAsDriver(true)}>View as Driver</button>
            <h2>Saved Catalog</h2>
            <div className="product-container">
                {savedItems.map((item, index) => (
                    <div className="product-card" key={index}>
                        <h3>{item.Title}</h3>
                        <img src={item.ImageURL} alt={item.Title} className="product-image" />
                        <p>Price: {item.Price}</p>
                        <div className="inventory-controls">
                            <p style={{ marginBottom: '4px' }}>
                                Current Inventory: {item.Inventory ?? 0}
                            </p>
                            <input type="number" min="0" className="inventory-input"
                                value={
                                    editedInventory[item.CatalogItemID] !== undefined
                                        ? editedInventory[item.CatalogItemID]
                                        : item.Inventory?.toString() || "0"
                                }
                                onChange={(e) => handleInventoryInput(item.CatalogItemID, e.target.value)}
                            />
                            <button onClick={() => handleInventorySave(item.CatalogItemID)}>Save</button>
                        </div>
                        <p>Added: {new Date(item.DateAdded).toLocaleDateString()}</p>
                        <button className="cancel-btn" onClick={() => removeItem(item.CatalogItemID)}>Remove</button>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default SavedCatalog;