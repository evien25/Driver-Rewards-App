import React, { useEffect, useState } from "react";
import {
    Link,
    Route,
    BrowserRouter as Router,
    Routes,
    useNavigate,
} from "react-router-dom";
import AccRegister from "./AccRegister.js";
import AdminDash from "./AdminDash.js";
import Cart from "./Cart.jsx";
import Catalog from './Catalog.jsx';
import CreateSpsUser from "./CreateSpsUser.js";
import DriverCatalog from "./DriverCatalog.jsx";
import DriverDash from "./DriverDash.js";
import Login from './Login.js';
import Logout from './Logout.js';
import PasswordResetForm from "./passreset/ResetForm.js";
import PasswordResetRequest from "./passreset/ResetRequest.js";
import Points from "./Points.js";
import Profile from './Profile.js';
import PurchaseHistory from "./PurchaseHistory.jsx";
import Report from "./Reports.js";
import SavedCatalog from './SavedCatalog.jsx';
import SpsApp from "./SpsApp.js";
import SpsDash from "./SpsDash.js";
import Status from './Status.js';
import SpsPoints from "./SpsPoints.jsx";
import homestyle from "./css/home.module.css";
import UserTable from "./usertable.js";

// Home Page Component
const Home = () => {
    return (
        <body>
            <header>
                <div class={homestyle.container}>
                    <div class={homestyle.logo}>
                        <a href="/"><img src="https://www.sorm.state.tx.us/wp-content/uploads/2020/10/defensive-driving-logo-color.png" alt="DriveWise Rewards Logo" /></a>
                        <h1>Driver Rewards</h1>
                    </div>
                    <nav>
                        <ul>
                            <li><Link to="/about" class={homestyle.nav_link}>About</Link></li>
                            <li><Link to="/AccRegister" class={homestyle.nav_link}>Sign Up</Link></li>
                            <li><Link to="/Login" class={homestyle.nav_link}>Log In</Link></li>
                        </ul>
                    </nav>
                </div>
            </header>  
        <section class={homestyle.hero}>
            <div class={homestyle.container}>
                <div class={homestyle.hero_content}>
                    <h1>Unlock Rewards for Every Safe Mile</h1>
                    <p>Join DriveWise Rewards and get recognized for your good driving habits. Earn points, redeem exciting rewards, and save on your car expenses.</p>
                    <Link to="/AccRegister" class={`${homestyle.button} ${homestyle.primary}`}>Sign Up Now</Link>
                    <a href="#" class={`${homestyle.button} ${homestyle.secondary}`}>Learn More</a>
                </div>
                <div class={homestyle.hero_image}>
                    <img src="https://i.ytimg.com/vi/p4u0Z4OxMDY/maxresdefault.jpg" alt="Car driving safely on a road" />
                </div>
            </div>
        </section>

        <section class={homestyle.features}>
            <div class={homestyle.container}>
                <h2>How It Works</h2>
                <div class={homestyle.feature_grid}>
                    <div class={homestyle.feature_item}>
                        <img src="https://cdn1.iconfinder.com/data/icons/location-and-map-8/60/car__location__map__tracking__vehicle-512.png" alt="Track Your Driving Icon" width="50" height="50"/>
                        <h3>Effortless Logging</h3>
                        <p>You enter your driving records, your sponsor will review the logs</p>
                    </div>
                    <div class={homestyle.feature_item}>
                        <img src="https://static.vecteezy.com/system/resources/previews/009/198/475/non_2x/earn-reward-points-icon-style-vector.jpg" alt="Earn Points Icon" width="50" height="50"/>
                        <h3>Earn Points Automatically</h3>
                        <p>Get rewarded with points for safe braking, smooth acceleration, and consistent speeds.</p>
                    </div>
                    <div class={homestyle.feature_item}>
                        <img src="https://cdn-icons-png.flaticon.com/512/5499/5499578.png" alt="Redeem Rewards Icon" width="50" height="50"/>
                        <h3>Redeem for Amazing Rewards</h3>
                        <p>Choose from a wide selection of rewards, including gift cards, tech, and more.</p>
                    </div>
                </div>
            </div>
        </section>

        <section class={homestyle.rewards_preview}>
            <div class={homestyle.container}>
                <h2>A Sneak Peek at Your Rewards</h2>
                <div class={homestyle.rewards_carousel}>
                    <div class={homestyle.reward_item}>
                        <img src="https://cdn-icons-png.freepik.com/512/2611/2611152.png" alt="Gift Card Reward" width="100" height="100"/>
                        <p>Gift Cards</p>
                    </div>
                    <div class={homestyle.reward_item}>
                        <img src="https://cdn-icons-png.flaticon.com/512/607/607921.png" alt="Home Items" width="100" height="100"/>
                        <p>Music</p>
                    </div>
                    <div class={homestyle.reward_item}>
                        <img src="https://cdn-icons-png.flaticon.com/512/8330/8330660.png" alt="Tech Gadget Reward" width="100" height="100"/>
                        <p>Tech Gadgets</p>
                    </div>
                </div>
                <a href="#" class={homestyle.button}>View All Rewards</a>
            </div>
        </section>

        <footer>
            <div class={homestyle.container}>
                <p>&copy; 2025 Driver Rewards. All rights reserved.</p>
                <nav>
                    <ul>
                        <li><a href="#" class={homestyle.footer_link}>Privacy Policy</a></li>
                        <li><a href="#" class={homestyle.footer_link}>Terms of Service</a></li>
                        <li><a href="#" class={homestyle.footer_link}>Contact Us</a></li>
                    </ul>
                </nav>
            </div>
        </footer>
    </body>
    );
};


// Public Navbar Component
const PublicNav = ({ isLoggedIn }) => (
    <header>
        <div class={homestyle.container}>
            <div class={homestyle.logo}>
                <a href="/"><img src="https://www.sorm.state.tx.us/wp-content/uploads/2020/10/defensive-driving-logo-color.png" alt="DriveWise Rewards Logo" /></a>
                <h1>Driver Rewards</h1>
            </div>
            <nav>
                <ul>
                    <li><Link to="/about" class={homestyle.nav_link}>About</Link></li>
                    <li><Link to="/AccRegister" class={homestyle.nav_link}>Sign Up</Link></li>
                    <li><Link to="/Login" class={homestyle.nav_link}>Log In</Link></li>
                </ul>
            </nav>
        </div>
    </header>
);

// Logged-in Navbar Component
const LoggedInNav = ({ role, onLogout }) => (
    <header>
        <div class={homestyle.container}>
            <div class={homestyle.logo}>
                <a href="/"><img src="https://www.sorm.state.tx.us/wp-content/uploads/2020/10/defensive-driving-logo-color.png" alt="DriveWise Rewards Logo" /></a>
                {role === "driver" && (
                    <h1>Driver Dashboard</h1>
                )}
                {role === "admin" && (
                    <h1>Admin Dashboard</h1>
                )}
                {role === "sponsoruser" && (
                    <h1>Sponsor Dashboard</h1>
                )}
            </div>
            <nav>
                <ul>
                    {role === "driver" && (
                        <li><Link to="/DriverDash" class={homestyle.nav_link}>Home</Link></li>
                    )}
                    {role === "admin" && (
                        <li><Link to="/admindash" class={homestyle.nav_link}>Home</Link></li>
                    )}
                    {role === "sponsoruser" && (
                        <li><Link to="/SpsDash" class={homestyle.nav_link}>Home</Link></li>
                    )}
                    <li><Link to="/logout" class={homestyle.nav_link}onClick={onLogout}>Logout</Link></li>
                </ul>
            </nav>
        </div>
    </header>
);

function App() {
    const [data, setData] = useState({
        isLoggedIn: false,
        role: null,
    });

    // Function to check login status from localStorage
    const checkLoginStatus = () => {
        const userId = localStorage.getItem('userid');
        const role = localStorage.getItem('role');
        setData({
            isLoggedIn: userId && Number(userId) > 0,
            role: role || null,
        });
    };

    // Run on mount and whenever localStorage changes
    useEffect(() => {
        checkLoginStatus(); // Initial check

        // Optional: Listen for storage changes (e.g., from another tab)
        window.addEventListener('storage', checkLoginStatus);
        return () => window.removeEventListener('storage', checkLoginStatus);
    }, []); // Empty array means it only runs on mount

    const handleLogout = () => {
        localStorage.removeItem('userid');
        localStorage.removeItem('role');
        localStorage.removeItem('address');
        localStorage.removeItem('profile');
        localStorage.removeItem('driverPoints');
        localStorage.removeItem('reportData');
        localStorage.removeItem('sprintData');
        localStorage.removeItem('DriverID');
        localStorage.removeItem('organization_id');
        localStorage.removeItem('point_balance');
        localStorage.removeItem('token');
        setData({ isLoggedIn: false, role: null }); // Update state immediately
    };

    return (
        <Router>
            {/* Public Navbar */}
            {!data.isLoggedIn && (<PublicNav isLoggedIn={data.isLoggedIn} /> )}

            {/* Logged-in Navbar */}
            {data.isLoggedIn && (
                <LoggedInNav role={data.role} onLogout={handleLogout} />
            )}

            {/* Routes also hides admin routes*/}
            <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/about" element={<Status />} />
                <Route path="/usertable" element={<UserTable />} />
                <Route path="/status" element={<Status />} />
                <Route path="/login" element={<Login />} />
                <Route path="/profile" element={<Profile />} />
                <Route path="/catalog" element={<Catalog />} />
                <Route path="/SavedCatalog" element={<SavedCatalog />} />
                <Route path="/driver-catalog" element={<DriverCatalog />} />
                <Route path="/points" element={<Points />} />
                <Route path="/cart" element={<Cart />} />
                <Route path="/purchase-history" element={<PurchaseHistory />} />
                <Route path="/logout" element={<Logout />} />
                <Route path="/AccRegister" element={<AccRegister />} />
                <Route path="/initreset" element={<PasswordResetRequest />} />
                <Route path="/reset-password" element={<PasswordResetForm />} />
                <Route path="/DriverDash" element={<DriverDash onLogout={handleLogout} />} />
                <Route path="/admindash" element={<AdminDash onLogout={handleLogout} />} />
                <Route path="/reports" element={<Report/>} />
                <Route path="/SpsDash" element={<SpsDash onLogout={handleLogout} />} />
                <Route path="/Catalog" element={<Catalog/>} />
                <Route path="/CreateSpsUser" element={<CreateSpsUser/>} />
                <Route path="/SpsPoints" element={<SpsPoints/>} />
                <Route path="/SpsApp" element={<SpsApp/>} />
            </Routes>
        </Router>
    );
}

export default App;