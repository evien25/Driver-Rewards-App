import React, { useState, useEffect } from 'react';

function About() {
  const [aboutData, setAboutData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetch('${/api/about')  // Fetch data from Flask backend
      .then(res => {
        if (!res.ok) {
          throw new Error(`HTTP error! status: ${res.status}`);
        }
        return res.json();
      })
      .then(data => {
        setAboutData(data);
        setLoading(false);
      })
      .catch(err => {
        setError(err);
        setLoading(false);
      });
  }, []); // Empty dependency array ensures this runs only once on mount

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error: {error.message}</div>;
  }

  if (!aboutData) { // In case data remains null for some other reason
      return <div>No data available.</div>
  }

  return (
    <div>
      <h1>{aboutData.title}</h1>
      <p>{aboutData.content}</p>
      <h2>Our Team</h2>
      <th>
        {aboutData.team.map((member, index) => (
          <td key={index}>{member.name} - {member.role}</td>
        ))}
      </th>
    </div>
  );
}

export default About;