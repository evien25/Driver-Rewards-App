import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

function DriverPoints() {
  const [pointsData, setPointsData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const userid = localStorage.getItem('userid');

    const fetchPointsFromDB = async () => {
      try {
        const response = await fetch(`${process.env.REACT_APP_API_URL}/api/points`, {
          headers: {
            Authorization: `Bearer ${userid}`, // Send token in Authorization header
          },
        });
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        setPointsData(data);
        localStorage.setItem('driverPoints', JSON.stringify(data)); // Cache in localStorage
        setError(null);
      } catch (err) {
        console.error('Error fetching driver points:', err);
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    // Check localStorage first
    const storedPoints = localStorage.getItem('driverPoints');
    if (false) {
      setPointsData(JSON.parse(storedPoints));
      setLoading(false);
    } else {
      fetchPointsFromDB();
    }
  }, [navigate]);

  if (loading) {
    return <div>Loading points...</div>;
  }

  return (
    <table>
        <thead>
            <tr>
                <th>Organization</th>
                <th>Points</th>
            </tr>
        </thead>
        <tbody>
            {pointsData.map((data, index) => (
                <tr key={index}>
                    <td>{data.Organization}</td>
                    <td>{data.Points}</td>
                </tr>
            ))}
        </tbody>
    </table>);
}

export default DriverPoints;