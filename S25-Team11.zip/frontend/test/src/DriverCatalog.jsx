import React, { useEffect, useState } from "react";
import "./Catalog.css";

const DriverCatalog = () => {
    const role = localStorage.getItem("role");
    const [items, setItems] = useState([]);
    const orgId = parseInt(localStorage.getItem("organization_id"));
    const pointBalance = parseInt(localStorage.getItem("point_balance"));

    useEffect(() => {
        const fetchCatalog = async () => {
            try {
                const res = await fetch(`${process.env.REACT_APP_API_URL}/api/catalog/${orgId}`);
                // console.log("Fetching org catalog for org ID:", orgId);
                const data = await res.json();
                if (!res.ok) throw new Error(data.error);
                setItems(data);
            } catch (err) {
                console.error("Failed to fetch catalog:", err);
            }
        };
        fetchCatalog();
    }, [orgId]);

    const addToCart = (item) => {
        const cart = JSON.parse(localStorage.getItem("driver_cart")) || [];
        const existingItem = cart.find((e) => e.CatalogItemID === item.CatalogItemID); // array parsing methodology

        // if product is already in cart, add one to amount
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
        // if not in cart, add it to the cart array
            cart.push({
                CatalogItemID: item.CatalogItemID,
                Title: item.Title,
                Price: item.Price,
                ImageURL: item.ImageURL,
                quantity: 1
            });
        }

        localStorage.setItem("driver_cart", JSON.stringify(cart));
        alert(`${item.Title} added to cart!`);
    };

    return (
        <div className="catalog-container">
            <h2>Organization Catalog (Driver View)</h2>
            <div className="product-container">
                {items.map((item, index) => (
                    <div key={index} className="product-card">
                        <h3>{item.Title}</h3>
                        <img src={item.ImageURL} alt={item.Title} className="product-image" />
                        <p>Price: {item.Price}</p>
                        <p>Inventory: {item.Inventory}</p>
                        <button
                            disabled={role !== "driver"}
                            onClick={() => addToCart(item)}
                        >Add to Cart</button>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default DriverCatalog;