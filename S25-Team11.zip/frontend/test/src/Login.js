import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './css/login.css';

function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const response = await fetch(`${process.env.REACT_APP_API_URL}/api/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username, password }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Login failed');
      }

      const data = await response.json();

      if (data.success) {
        localStorage.setItem('userid', data.userid);
        localStorage.setItem('role', data.role);

        if (data.role === 'admin') {
            window.location.href = '/admindash';
          } 
        else if (data.role === 'sponsoruser') {
            const sponsorRes = await fetch(`${process.env.REACT_APP_API_URL}/api/sponsor-info/${data.userid}`);
            const sponsorData = await sponsorRes.json();
            if (sponsorRes.ok) {
              localStorage.setItem('organization_id', sponsorData.organization_id);
              window.location.href = '/SpsDash';
            } else {
              setError('Sponsor profile incomplete or missing.');
              return;
            }
          } 
        else {
          localStorage.setItem('DriverID', data.driverID);
          const driverRes = await fetch(`${process.env.REACT_APP_API_URL}/api/driver-info/${data.userid}`);
          const driverData = await driverRes.json();
          if (driverRes.ok) {
            localStorage.setItem('organization_id', driverData.organization_id);
            localStorage.setItem('point_balance', driverData.point_balance);
            window.location.href = '/DriverDash';
          } else {
            setError(data.message || 'Driver info retrieval failed');
          }
        }
      } 
      else {
        setError(data.message || 'Login failed');
      }
    } catch (err) {
      setError(err.message || 'An error occurred. Please try again later.');
      console.error("Login Error:", err);
    } finally {
      setLoading(false);
    }
  };

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  return (
    <div className="login-container">
      <h2>Login</h2>
      <form onSubmit={handleSubmit}>
        <div className="input-group">
          <label htmlFor="username">Username:</label>
          <input
            type="text"
            id="username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
          />
        </div>
        <div className="input-group">
          <label htmlFor="password">Password:</label>
          <div className="password-container">
            <input
              type={showPassword ? 'text' : 'password'}
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
            <button
              type="button"
              className="password-toggle"
              onClick={togglePasswordVisibility}
              aria-label={showPassword ? 'Hide password' : 'Show password'}
            >
              {showPassword ? 'Hide' : 'Show'}
            </button>
          </div>
        </div>
        {error && <div className="error-message">{error}</div>}
        <button type="submit" disabled={loading}>
          {loading ? 'Logging in...' : 'Login'}
        </button>
        <Link to="/AccRegister">
          <button type="button">Create Account</button>
        </Link>
        <Link to="/initreset">
          <button type="button">Reset Password</button>
        </Link>
      </form>
    </div>
  );
}

export default Login;
