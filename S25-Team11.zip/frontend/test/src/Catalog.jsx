import React, { useState } from "react";
import { Link } from "react-router-dom";
import "./Catalog.css";

const Catalog = () => {
    const [products, setProducts] = useState([]);
    const [searchQuery, setSearchQuery] = useState("");

    const searchEbay = async () => {
        if (!searchQuery) {
            console.error("Search query is empty.");
            return;
        }
    
        try {
            const response = await fetch(`${process.env.REACT_APP_API_URL}/api/ebay/search?q=${encodeURIComponent(searchQuery)}`, {
                method: "GET",
                headers: {
                    "Content-Type": "application/json"
                }
            });
    
            const data = await response.json();
            console.log("eBay API Response:", data);  // debug lines
    
            if (data.itemSummaries) {
                setProducts(data.itemSummaries.map(item => ({
                    ebay_id: item.itemId,
                    title: item.title,
                    price: `${item.price.value} ${item.price.currency}`,
                    url: item.itemWebUrl,
                    image: item.image.imageUrl
                })));
            } else {
                setProducts([]);
                console.warn("No results found.");
            }
        } catch (error) {
            console.error("Error fetching eBay items:", error);
        }
    };

    const addToCatalog = async (product) => {
        const payload = {
            ebay_id: product.ebay_id,
            title: product.title,
            price: product.price,
            image: product.image,
            organization_id: parseInt(localStorage.getItem("organization_id")),
            sponsor_user_id: parseInt(localStorage.getItem("sponsor_user_id"))
        };
    
        try {
            const response = await fetch(`${process.env.REACT_APP_API_URL}/api/catalog`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(payload)
            });
    
            const data = await response.json();
            if (!response.ok) throw new Error(data.error);
            console.log("Added to catalog:", data);
        } catch (err) {
            console.error("Error adding to catalog:", err);
        }
    };

    return (
        <div className="catalog-container">
            <h2>Catalog</h2>

            <div>
                <Link to="/SavedCatalog" className="link-button">Go to Saved Catalog</Link>
            </div>

            <div className="search-container">
                <input
                    type="text"
                    className="input-group"
                    placeholder="Search eBay..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                />
                <button className="search-btn" onClick={searchEbay}>Search</button>
            </div>

            <div className="product-container">
                {products.map((product, index) => (
                    <div key={index} className="product-card">
                        <h3>{product.title}</h3>
                        <img src={product.image} className="product-image" alt={product.title} />
                        <p>Price: {product.price}</p>
                        <button onClick={() => addToCatalog(product)}>Add to Catalog</button>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default Catalog;
