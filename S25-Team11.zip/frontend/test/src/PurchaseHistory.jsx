import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Catalog.css";

const PurchaseHistory = () => {
    const role = localStorage.getItem("role");
    const [history, setHistory] = useState([]);
    const navigate = useNavigate();

    useEffect(() => {
        if (role !== "driver") {
            alert("Only drivers can access the cart.");
            navigate("/profile");
        }
        
        const driverId = localStorage.getItem("userid");

        const fetchHistory = async () => {
            try {
                const res = await fetch(`${process.env.REACT_APP_API_URL}/api/purchase-history/${driverId}`);
                const data = await res.json();
                if (!res.ok) throw new Error(data.error);
                setHistory(data);
            } catch (err) {
                console.error("Failed to load purchase history:", err);
            }
        };

        fetchHistory();
    }, []);

    return (
        <div className="history-container">
            <h2>Purchase History</h2>
            {history.length === 0 ? ( <p>No previous purchases found.</p> ) : (
                history.map((purchase) => {
                    const items = JSON.parse(purchase.Items);
                    return (
                        <div key={purchase.PurchaseID} className="purchase-box">
                            <strong>Date:</strong> {new Date(purchase.PurchaseDate).toLocaleDateString()}
                            <div>
                                {items.map((item, index) => (
                                    <div key={index} className="purchase-item">
                                        <img src={item.ImageURL} alt={item.Title} />
                                        <div className="purchase-item-details">
                                            <h4>{item.Title}</h4>
                                            <p>Quantity: {item.quantity}</p>
                                            <p>Price: {item.Price}</p>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    );
                })
            )}
        </div>
    );
};

export default PurchaseHistory;