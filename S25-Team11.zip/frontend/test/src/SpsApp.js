import React, { useState, useEffect, useRef } from 'react';

function SpsApp() {
    const [email, setEmail] = useState('');
    const [FName, setFName] = useState('');
    const [LName, setLName] = useState('');
    const [phonenumber, setPhonenumber] = useState('');
    const [sponsor, setSponsor] = useState('');
    const [Description, setDescription] = useState('');
    const [SponsorInfo, setSponsorInfo] = useState([]);
    const [error, setError] = useState('');
    // Set initial loading state for the initial data fetch if desired
    const [loading, setLoading] = useState(true); // Start loading initially
    const hasFetched = useRef(false);

    // Removed state setters from component body

    useEffect(() => {
        if (!hasFetched.current) {
            // Optionally set loading to true here if not done initially
            // setLoading(true); // Set loading before fetch starts
            getLists()
              .catch(err => { // Add catch block for fetch errors
                console.error("Failed to get lists:", err);
                setError('Failed to load sponsor list. Please refresh.');
              })
              .finally(() => {
                setLoading(false); // Set loading to false after fetch completes (success or fail)
              });
            hasFetched.current = true;
        } else {
            // If hasFetched is true, we might not be loading anymore
            // If you didn't set initial loading state to true, set it false here
             if (loading) setLoading(false);
        }
        console.log("Effect ran"); // Changed log message for clarity
    }, []); // Keep dependency array empty

    async function getLists() {
        // No need to set loading/error here, handled in useEffect or handleSubmit1

        const userID = localStorage.getItem('userid');
        // Removed orgID fetching as it wasn't used in the fetch body

        const response = await fetch(`${process.env.REACT_APP_API_URL}/api/SpsApp`, { // Flask route
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ userID, currPost: "1" }), // Send userID and post type
        });

        // Check if response is ok BEFORE trying to parse JSON
        if (!response.ok) {
            // Handle HTTP errors during fetch
            let errorMsg = `HTTP error! status: ${response.status}`;
            try {
                const errorData = await response.json();
                errorMsg = errorData.message || errorMsg;
            } catch (parseError) {
                // If JSON parsing fails, use the status text
                errorMsg = response.statusText || errorMsg;
            }
            throw new Error(errorMsg); // Throw error to be caught by .catch in useEffect
        }

        const SponsorData = await response.json();
        console.log("SponsorData received:", SponsorData);

        // Ensure SponsorData is an array before mapping
        if (Array.isArray(SponsorData)) {
             setSponsorInfo(SponsorData.map(sps => ({
                orgName: sps.Name,
                spsID: sps.orgID,
            })));
        } else {
            console.error("Received non-array data for sponsors:", SponsorData);
            setError("Received invalid sponsor data format.");
            setSponsorInfo([]); // Set to empty array to prevent map errors
        }
    }

    async function handleSubmit1(userID, OrgID, description) {
        // Set loading and clear previous errors when submit starts
        setError('');
        setLoading(true);

        try {
            const response = await fetch(`${process.env.REACT_APP_API_URL}/api/SpsApp`, { // Flask route
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ userID, OrgID, description, currPost: "2" }), // Send data
            });

            if (!response.ok) {
                const errorData = await response.json().catch(() => ({ message: 'Application Failed due to server error.' })); // Attempt to parse error, provide fallback
                throw new Error(errorData.message || 'Application Failed');
            }

            const data = await response.json();
            if (data.success) {
                window.location.href = '/DriverDash'; // Navigate on success
            } else {
                setError(data.message || 'Application submission failed');
            }

        } catch (err) {
            setError(err.message || 'An error occurred during submission. Please try again.');
            console.error("Submit Error:", err);
        } finally {
            // Ensure loading is set to false regardless of success/failure
            setLoading(false);
        }
    };

    // Check event handlers - they look syntactically correct (using arrow functions)
    return (
        <div className="SPAContainer"> {/* Use className instead of class in React */}
            <form>
                <h2>Application Form</h2>
                <label htmlFor="Description">Please provide a reason of why you would be a good fit to work with us.</label> {/* Use htmlFor */}
                <textarea id="coverLetter" name="coverLetter" rows="6" required
                    value={Description} // Controlled component: value should be linked to state
                    onChange={(e) => setDescription(e.target.value)}
                />
                {/* Display loading indicator */}
                {loading && <p>Loading...</p>}
                {/* Display error message */}
                {error && <p style={{ color: 'red' }}>Error: {error}</p>}

                <table className="user-table"> {/* Use className */}
                    <tbody>
                        {/* Conditionally render only if SponsorInfo has data */}
                        {!loading && SponsorInfo.length === 0 && (
                            <tr><td colSpan="1">No sponsors found or failed to load.</td></tr>
                        )}
                        {!loading && SponsorInfo.map((sps, index) => (
                            <tr key={sps.spsID || index} className="user-row"> {/* Use a more stable key if spsID is unique */}
                                <td>
                                    {/* Disable button while submitting */}
                                    <button type="button" disabled={loading} onClick={() => {
                                        console.log("Submitting for OrgID:", sps.spsID);
                                        const userID = localStorage.getItem('userid');
                                        // Add check for description - maybe ensure it's not empty?
                                        if (!Description.trim()) {
                                            setError("Please provide a description.");
                                            return;
                                        }
                                        handleSubmit1(userID, sps.spsID, Description);
                                    }}>
                                        Apply to {sps.orgName}
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>

                {/* Disable button while loading/submitting */}
                <button type="button" disabled={loading} onClick={() => { window.location.href = '/DriverDash' }} >Cancel Application</button>
            </form>
        </div>
    );
}

export default SpsApp;