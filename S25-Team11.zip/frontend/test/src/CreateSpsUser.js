import React, { useState, useEffect } from 'react';

function CreateSpsUser() {

        const [username, setUsername] = useState('');
        const [password, setPassword] = useState('');
        const [email, setEmail] = useState('');
        const [FName, setFName] = useState('');
        const [LName, setLName] = useState('');
        const [phonenumber, setPhonenumber] = useState('');
        const [sponsor, setSponsor] = useState('');
        const [error, setError] = useState('');
        const [loading, setLoading] = useState(false);

    
        const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');
        setLoading(true);
    
        try {
            const response = await fetch(`${process.env.REACT_APP_API_URL}/api/AccRegister`, { // Flask route
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ email , username, password , FName , LName , phonenumber}), // Send username/password in JSON
            });
    
            if (!response.ok) {  // Check for HTTP errors (400, 500, etc.)
            const errorData = await response.json(); // Try to parse error message from Flask
            throw new Error(errorData.message || 'Login failed'); // Throw the error to be caught
            }
    
            const data = await response.json(); // Assuming Flask returns JSON with a token
            if (data.success) {
                 // Save the token to local storage
            window.location.href = '/SpsDash'; //navigate to home
            
        } else {
            setError(data.message || 'Login failed'); // Display Flask-provided message or generic message
            }
    
        } catch (err) {
            setError(err.message || 'An error occurred. Please try again later.');
            console.error("Login Error:", err);
        } finally {
            setLoading(false);
        }

    }; 

    return (
        <div>

            <div class="ARForm-container">
                <h2>Create a Sponsor User</h2>
                <form onSubmit={handleSubmit}>
                    <div class="ARForm-group">

                        <label for="First Name">First Name</label>
                        <input type="text" id="Fname" name="Fname" 
                        required placeholder="Enter first name"
                        value={FName}
                        onChange={(e) => setFName(e.target.value)}
                        />
                    </div>
                    <div class="ARForm-group">
                        <label for="Last Name">Last Name</label>
                        <input type="text" id="Lname" name="Lname" 
                        required placeholder="Enter last name"
                        value={LName}
                        onChange={(e) => setLName(e.target.value)}
                        />
                    </div>
                    <div class="ARForm-group">
                        <label for="email">Email Address</label>
                        <input type="email" id="email" name="email"
                        required placeholder="Enter email address"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        />
                    </div>
                    <div class="ARForm-group">
                        <label for="Phonenumber">Phonenumber</label>
                        <input type="text" id="Phonenumber" name="Phonenumber"
                        required placeholder="Enter phonenumber"
                        value={phonenumber}
                        onChange={(e) => setPhonenumber(e.target.value)}
                        />
                    </div>
                    <div class="ARForm-group">
                        <label for="Username">Username</label>
                        <input type="text" id="Username" name="Username" 
                        required placeholder="Enter username"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        />
                    </div>
                    <div class="ARForm-group">
                        <label for="password">Password</label>
                        <input type="password" id="password" name="password" 
                        required placeholder="Enter password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}/>
                    </div>
                    
                    <button type="submit" disabled={loading} href="/..">Submit </button>
                </form>
            </div>
        </div>
      );
}

export default CreateSpsUser;