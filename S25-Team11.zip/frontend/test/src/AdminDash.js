import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import './css/driverdash.css';

function AdminDash({ onLogout }) {

  return (
    <div className="driver-dash-container">
      <div className="dashboard-content">
        <div className="button-grid">
          <Link to="/profile" className="grid-button">Profile</Link>
          <Link to="/usertable" className="grid-button">User Management</Link>
          <Link to="/reports" className="grid-button">Reports</Link>
        </div>
      </div>
    </div>
  );
}

export default AdminDash;