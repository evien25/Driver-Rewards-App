import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Catalog.css";

const Cart = () => {
    const role = localStorage.getItem("role");
    const [cartItems, setCartItems] = useState([]);
    const navigate = useNavigate();

    useEffect(() => {
        if (role !== "driver") {
            alert("Only drivers can access the cart.");
            navigate("/profile");
        }

        // cart initialization or retrieval
        const savedCart = JSON.parse(localStorage.getItem("driver_cart")) || [];
        setCartItems(savedCart);
    }, []);

    const handleCheckout = async () => {
        const driverId = localStorage.getItem("userid");
        const pointBalance = parseFloat(localStorage.getItem("point_balance")) || 0;

        // calculate total cost of cart using reduce (accumulator arithimetic)
        const totalCost = cartItems.reduce((sum, item) => {
          const price = parseFloat(item.Price);
          return sum + (price * item.quantity); // recurse through list of items in cart
        }, 0);

        if (totalCost > pointBalance) {
          alert('Insufficient point balance! Total cost: ${totalCost} : Current balance: ${pointBalance}');
          return;
        }

        try {
            const response = await fetch(`${process.env.REACT_APP_API_URL}/api/checkout`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ driver_id: driverId, items: cartItems })
            });

            const data = await response.json();
            if (!response.ok) throw new Error(data.error);

            alert("Purchase complete!");
            const newBalance = pointBalance - totalCost;
            localStorage.setItem("point_balance", newBalance.toFixed(2)); // ensures 2 decimal places
            localStorage.removeItem("driver_cart");
            navigate("/DriverDash");
        } catch (err) {
            console.error("Checkout failed:", err);
            alert("Checkout failed. Try again.");
        }
    };

    return (
        <div className="cart-container">
            <button onClick={() => navigate("/purchase-history")}>View Purchase History</button>
            <h2>Your Cart</h2>
            {cartItems.length === 0 ? ( <p>Your cart is empty.</p> ) : (
                <div className="cart-box">
                {cartItems.map((item, index) => (
                  <div key={index} className="cart-item">
                    <img src={item.ImageURL} alt={item.Title} />
                    <div className="cart-item-details">
                      <h4>{item.Title}</h4>
                      <p>Price: {item.Price}</p>
                      <p>Quantity: {item.quantity}</p>
                    </div>
                  </div>
                ))}
                <div className="cart-actions">
                  <button onClick={handleCheckout}>Proceed to Checkout</button>
                </div>
              </div>
            )}
          </div>
    );
};

export default Cart;