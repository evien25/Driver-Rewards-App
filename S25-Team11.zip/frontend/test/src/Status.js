import React, { useState, useEffect } from 'react';
import './css/about.css'

function Status() {
  const [status, setStatus] = useState('Checking...');
  const [error, setError] = useState(null);
  const [sprintData, setSprintData] = useState([]);

  useEffect(() => {
    // Fetch database status
    const checkDatabaseStatusFetch = async () => {
      try {
        const response = await fetch(`${process.env.REACT_APP_API_URL}/api/mysql/status`);
        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(`${response.status} ${response.statusText}: ${errorData.message || 'Database check failed'}`);
        }
        const data = await response.json();
        setStatus(data.status); // e.g., "up" or "down"
        setError(null);
      } catch (err) {
        console.error('Error checking database status:', err);
        setStatus('Error');
        setError(err.message);
      }
    };

    // Fetch sprint data from DB
    const fetchSprintDataFromDB = async () => {
      try {
        const response2 = await fetch(`${process.env.REACT_APP_API_URL}/api/sprint_data`);
        if (!response2.ok) {
          throw new Error(`HTTP error! status: ${response2.status}`);
        }
        const data2 = await response2.json();
        setSprintData(data2);
        localStorage.setItem('sprintData', JSON.stringify(data2)); // Save to localStorage
        setError(null);
      } catch (err) {
        console.error('Error fetching sprint data:', err);
        setError(err.message);
      }
    };

    // Check localStorage first for sprint data
    const storedSprintData = localStorage.getItem('sprintData');
    if (storedSprintData) {
      setSprintData(JSON.parse(storedSprintData)); // Use cached data if available
    } else {
      fetchSprintDataFromDB(); // Fetch from DB if localStorage is empty
    }

    // Always check database status on mount
    checkDatabaseStatusFetch();
  }, []); // Empty dependency array means this runs only once on mount

  return (
    <div>
      <h2>Database Status: {status}</h2>
      {error && <p style={{ color: 'red' }}>Error: {error}</p>} {/* Conditionally render error */}
      <table>
        <thead>
          <tr>
            <th>Team</th>
            <th>Version</th>
            <th>Release Date</th>
            <th>Product Name</th>
            <th>Description</th>
          </tr>
        </thead>
        <tbody>
          {sprintData.map((sprint) => (
            <tr key={sprint.Team + sprint.Version + sprint.ProductName}> {/* Unique key */}
              <td>{sprint.Team}</td>
              <td>{sprint.Version}</td>
              <td>{new Date(sprint.ReleaseDate).toLocaleDateString()}</td> {/* Format date */}
              <td>{sprint.ProductName}</td>
              <td>{sprint.ProductDescription}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default Status;