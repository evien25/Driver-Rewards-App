import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

function Report() {
  const [reportData, setreportData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const userid = localStorage.getItem('userid');

    const fetchreportData = async () => {
      try {
        const response = await fetch(`${process.env.REACT_APP_API_URL}/api/report`);
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        setreportData(data);
        localStorage.setItem('reportData', JSON.stringify(data)); // Cache in localStorage
        setError(null);
      } catch (err) {
        console.error('Error fetching driver points:', err);
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    // Check localStorage first
    const storedReport = localStorage.getItem('reportData');
    if (storedReport) {
      setreportData(JSON.parse(storedReport));
      setLoading(false);
    } else {
      fetchreportData();
    }
  }, [navigate]);

  // Handle download
  const handleDownload = () => {
    axios.get('/api/report/download', { responseType: 'blob' })
      .then(response => {
        // Create a blob URL and trigger download
        const url = window.URL.createObjectURL(new Blob([response.data]));
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', 'records.csv');
        document.body.appendChild(link);
        link.click();
        link.parentNode.removeChild(link);
        window.URL.revokeObjectURL(url);
      })
      .catch(error => {
        console.error('Error downloading file:', error);
      });
  };

  if (loading) {
    return <div>Loading points...</div>;
  }

  return (
    <div>
      <button 
        onClick={handleDownload}>
        Download CSV
      </button>
      <table>
          <thead>
              <tr>
                  <th>Table</th>
                  <th>Action</th>
                  <th>Field Changed</th>
                  <th>Old Value</th>
                  <th>New Value</th>
                  <th>Changed by</th>
                  <th>Timestamp</th>
              </tr>
          </thead>
          <tbody>
              {reportData.map((data, index) => (
                  <tr key={index}>
                      <td>{data.Table}</td>
                      <td>{data.Action}</td>
                      <td>{data.FieldChanged}</td>
                      <td>{data.OldValue}</td>
                      <td>{data.NewValue}</td>
                      <td>{data.Changedby}</td>
                      <td>{data.Timestamp}</td>
                  </tr>
              ))}
          </tbody>
      </table>
    </div>);
}

export default Report;