import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";

function Logout() {
    const navigate = useNavigate();

    useEffect(() => {
        navigate("/login"); // Redirect after logout
    }, [navigate]);

    return <h2>Logging out...</h2>;
}

export default Logout;