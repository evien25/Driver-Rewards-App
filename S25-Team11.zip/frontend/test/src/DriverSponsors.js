import React, { useEffect, useState ,useRef} from 'react';
import { Link } from 'react-router-dom'; // Import Link for navigation

function DriverSponsors() {
  const [DriverID, setDriverID] = useState(0);
  const [Balance, setBalance] = useState(0);
  const [Reason , setReason] = useState('');
  const [Decision , setDecision] = useState('');
  const [Drivers , setDrivers] = useState([]);
  const [AppList , setAppList] = useState([]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [SpsUserID , setSpsUserID] = useState(0);
  const [DriverUserID , setDriverUserID] = useState(0);
  const hasFetched = useRef(false);


  useEffect(() => {
    if (!hasFetched.current) {
      getLists();
      hasFetched.current = true;
    }
    console.log("got Here3");
  } , [])
    

  async function getLists() {



    const orgID = localStorage.getItem('organization_id');

    const response = await fetch('/api/SpsPoints',{ // Flask route
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
        body: JSON.stringify({orgID , currPost: "1"} ,), // Send username/password in JSON
    });

    localStorage.getItem('organization_id')

    const DriverData = await response.json()
    console.log("got Here1");

    console.log(DriverData)
    setDrivers(DriverData.map(driver => ({
      FName: driver.FirstName,
      LName: driver.LastName,
      PBalance: driver.pointBalance,
      driverid: driver.driverID

    })));

    const response2 = await fetch('/api/SpsPoints', { // Flask route
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({orgID , currPost: "2"}),
    });

    const AppData = (await response2.json())
    console.log("got Here3");
    setAppList(AppData.map(app => ({
      FName: app.FirstName,
      LName: app.LastName,
      Description :app.Description,
      DUserID : app.UserID

    })));

  }
  
    

  const handleSubmit2 = async ( decision , driverUserID ) => {
    setError('');
    setLoading(true);


    const orgID = localStorage.getItem('organization_id');

    try {
      const response = await fetch('/api/SpsPoints', { // Flask route
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
        body: JSON.stringify({driverUserID , orgID , decision , currPost: "4"}), // Send username/password in JSON
      });

      if (!response.ok) {  // Check for HTTP errors (400, 500, etc.)
        const errorData = await response.json(); // Try to parse error message from Flask
        throw new Error(errorData.message || 'Login failed'); // Throw the error to be caught
      }

      const data = await response.json(); // Assuming Flask returns JSON with a userid
      if (data.success) {
        window.location.href = '/SpsPoints';
      } 
      else {
          setError(data.message || 'Login failed'); // Display Flask-provided message or generic message
      }

    } catch (err) {
      setError(err.message || 'An error occurred. Please try again later.');
      console.error("Login Error:", err);
    } finally {
      setLoading(false);
    }  

  };


  async function  handleSubmit1(driverID, spsUserID, reason, balance , positive){
    setError('');
    setLoading(true);

    try {
      const response = await fetch('/api/SpsPoints', { // Flask route
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
        body: JSON.stringify({driverID , balance , spsUserID , reason  , positive , currPost: "3"}), // Send username/password in JSON
      });

        if (!response.ok) {  // Check for HTTP errors (400, 500, etc.)
          const errorData = await response.json(); // Try to parse error message from Flask
          throw new Error(errorData.message || 'Login failed'); // Throw the error to be caught
        }
  
        const data = await response.json(); // Assuming Flask returns JSON with a userid
        if (data.success) {
          window.location.href = '/SpsPoints';
        } 
        else {
            setError(data.message || 'Login failed'); // Display Flask-provided message or generic message
        }
  
      } catch (err) {
        setError(err.message || 'An error occurred. Please try again later.');
        console.error("Login Error:", err);
      } finally {
        setLoading(false);
      }  

  };
  return (

    <div>

      <h2>Current Drivers</h2>
    
      <table class="user-table">
        <thead>
          <tr>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Point Balance</th>
            <th>Insert Reason</th>
            <th>Insert Number</th>
            <th>Add Points</th>
            <th>Remove Points</th>
          </tr>
        </thead>
        <tbody>
          {Drivers.map((driver, index) => (
            <tr key={index} class="user-row">
              <td>{driver.FName}</td>
              <td>{driver.LName}</td>
              <td>{driver.PBalance}</td>
              <td>
                <input type="text"
                required placeholder="Please provide a reason for the point changes"
                value={Reason}
                onChange={(e) => setReason(e.target.value)}
                />
              </td>

              <td>
                <input type="text"
                required placeholder="Add Points"
                onChange={(e) => setBalance(parseInt(e.target.value))}
                />
              </td>

              <td>
                <button onClick={() => {
                  console.log("test")
                  const driverID = driver.driverid;
                  const spsUserID = localStorage.getItem('SpsUserID');
                  const reason = Reason;
                  const balance = Balance;
                  const positive = "Positive"
                  handleSubmit1(driverID, spsUserID, reason, balance , positive);
                  }
                }> Add Points</button>

              </td>
                
              <td>
              <button onClick={function event() {
                  const driverID = driver.driverid;
                  const spsUserID = localStorage.getItem('SpsUserID');
                  const reason = Reason;
                  const balance = Balance;
                  const positive = "Negative"
                  handleSubmit1(driverID, spsUserID, reason, balance , positive);
                  }
                }> Remove Points</button>

              </td>

            </tr>
          ))}
        </tbody>
      </table>



      <h2>Applications</h2>
      

        <table class="user-table">
        <thead>
          <tr>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Description</th>
            <th>Accept</th>
            <th>Deny</th>
          </tr>
        </thead>
        <tbody>
      {AppList.map((apps, index) => (
          <tr key={index} class="user-row">
              <td>{apps.FName}</td>
              <td>{apps.LName}</td>
              <td>{apps.Description}</td>

              <td>
                <button onClick={function event() {
                  const decision = "Accept"
                  const driverUserID = apps.DUserID
                  handleSubmit2(decision , driverUserID)
                  }
                }> Accept</button>

              </td>

              <td>
                <button onClick={function event() {
                  const decision = "Deny"
                  const driverUserID = apps.DUserID
                  handleSubmit2(decision , driverUserID)
                  }
                }> Deny</button>
              </td>
          </tr>
      ))}
      </tbody>
      </table>
      
    </div>
  );

  
}

export default DriverSponsors;