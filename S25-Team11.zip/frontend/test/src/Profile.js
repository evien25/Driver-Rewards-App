import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import './css/profile.css'

function ProfilePage() {
  const [profile, setProfile] = useState(null);
  const [address, setAddress] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const [editedProfile, setEditedProfile] = useState(null);
  const [editedAddress, setEditedAddress] = useState(null);
  const [isEditingAddress, setIsEditingAddress] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const userid = localStorage.getItem('userid');
    if (!userid) {
      navigate('/login'); // Redirect if no token
      return;
    }

    const fetchProfileFromDB = async () => {
      try {
        const response = await axios.get(`${process.env.REACT_APP_API_URL}/api/profile`, {
          headers: {
            Authorization: `Bearer ${userid}`,
          },
        });
        const profileData = {
          ...response.data,
          PhoneNumber: response.data.PhoneNumber ? String(response.data.PhoneNumber) : '', // Cast phone number to string
        };
        setProfile(profileData);
        setEditedProfile(profileData);
        localStorage.setItem('profile', JSON.stringify(profileData)); // Save to localStorage
      } catch (error) {
        console.error('Error fetching profile:', error);
      }
    };

    const fetchAddressFromDB = async () => {
      try {
        const response = await axios.get(`${process.env.REACT_APP_API_URL}/api/address`, {
          headers: {
            Authorization: `Bearer ${userid}`,
          },
        });
        const addressData = response.data;
        setAddress(addressData);
        setEditedAddress(addressData);
        localStorage.setItem('address', JSON.stringify(addressData)); // Save to localStorage
      } catch (error) {
        console.error('Error fetching address:', error);
      }
    };

    // Check localStorage first
    const storedProfile = localStorage.getItem('profile');
    const storedAddress = localStorage.getItem('address');

    if (storedProfile) {
      const parsedProfile = JSON.parse(storedProfile);
      setProfile(parsedProfile);
      setEditedProfile(parsedProfile);
    } else {
      fetchProfileFromDB(); // Fetch from DB if localStorage is empty
    }

    if (storedAddress) {
      const parsedAddress = JSON.parse(storedAddress);
      setAddress(parsedAddress);
      setEditedAddress(parsedAddress);
    } else {
      fetchAddressFromDB(); // Fetch from DB if localStorage is empty
    }
  }, [navigate]); // Add navigate to dependency array

  // Handle profile edit
  const handleEdit = () => {
    setIsEditing(true);
  };

  // Handle address edit
  const handleAddressEdit = () => {
    setIsEditingAddress(true);
  };

  // Handle cancel button
  const handleCancel = () => {
    setIsEditing(false);
    setIsEditingAddress(false);
    setEditedProfile(profile); // Revert changes
    setEditedAddress(address);
  };

  // Used to save the profile
  const handleSave = async () => {
    try {
      await axios.put(`${process.env.REACT_APP_API_URL}/api/profile`, editedProfile); // Flask endpoint for update
      const updatedProfile = {
        ...editedProfile,
        PhoneNumber: String(editedProfile.PhoneNumber), // Ensure phone number is a string
      };
      setProfile(updatedProfile);
      setIsEditing(false);
      localStorage.setItem('profile', JSON.stringify(updatedProfile)); // Update localStorage
    } catch (error) {
      console.error('Error updating profile:', error);
    }
  };

  // Used to save the address
  const handleAddressSave = async () => {
    try {
      const userId = localStorage.getItem('userid'); // Retrieve userId from local storage
      const payload = {
        ...editedAddress, // Spread the existing editedAddress properties
        userId // Add userId to the payload
      };
      await axios.put(`${process.env.REACT_APP_API_URL}/api/address`, payload); // Flask endpoint for update
      setAddress(editedAddress);
      setIsEditingAddress(false);
      localStorage.setItem('address', JSON.stringify(editedAddress)); // Update localStorage
    } catch (error) {
      console.error('Error updating address:', error);
    }
  };

  // Handle the change of profile
  const handleChange = (e) => {
    const { name, value } = e.target;
    setEditedProfile((prevProfile) => ({
      ...prevProfile,
      [name]: name === 'PhoneNumber' ? String(value) : value, // Cast phone number to string
    }));
  };

  // Handle the address change
  const handleAddressChange = (e) => {
    const { name, value } = e.target;
    setEditedAddress((prevAddress) => ({
      ...prevAddress,
      [name]: value,
    }));
  };

  if (!profile && !address) {
    return <div>Loading...</div>;
  }

  return (
    <div className="profile-container">
      <div className="profile-header">
        <h1>Profile</h1>
        <img
          src="https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_1280.png"
          alt="Profile"
        />
      </div>
      {isEditing ? (
        <div className="profile-edit-form">
          <input
            type="text"
            name="FName"
            value={editedProfile?.FName || ''}
            onChange={handleChange}
            placeholder="First Name"
          />
          <input
            type="text"
            name="LName"
            value={editedProfile?.LName || ''}
            onChange={handleChange}
            placeholder="Last Name"
          />
          <input
            type="email"
            name="Email"
            value={editedProfile?.Email || ''}
            onChange={handleChange}
            placeholder="Email"
          />
          <input
            type="tel" // Use tel for phone numbers
            name="PhoneNumber"
            value={editedProfile?.PhoneNumber || ''}
            onChange={handleChange}
            placeholder="Phone Number"
          />
          <button onClick={handleSave}>Save</button>
          <button onClick={handleCancel}>Cancel</button>
        </div>
      ) : isEditingAddress ? (
        <div className="profile-edit-form">
          <input
            type="text"
            name="Street"
            value={editedAddress?.Street || ''}
            onChange={handleAddressChange}
            placeholder="Street"
          />
          <input
            type="text"
            name="Apt"
            value={editedAddress?.Apt || ''}
            onChange={handleAddressChange}
            placeholder="Apt"
          />
          <input
            type="text"
            name="City"
            value={editedAddress?.City || ''}
            onChange={handleAddressChange}
            placeholder="City"
          />
          <input
            type="text"
            name="State"
            value={editedAddress?.State || ''}
            onChange={handleAddressChange}
            placeholder="State"
          />
          <input
            type="text"
            name="Country"
            value={editedAddress?.Country || ''}
            onChange={handleAddressChange}
            placeholder="Country"
          />
          <input
            type="text"
            name="Zipcode"
            value={editedAddress?.Zipcode || ''}
            onChange={handleAddressChange}
            placeholder="Zipcode"
          />
          <button onClick={handleAddressSave}>Save</button>
          <button onClick={handleCancel}>Cancel</button>
        </div>
      ) : (
        <div className="profile-details">
          <p><strong>First Name:</strong> {profile?.FName || 'N/A'}</p>
          <p><strong>Last Name:</strong> {profile?.LName || 'N/A'}</p>
          <p><strong>Email:</strong> {profile?.Email || 'N/A'}</p>
          <p><strong>Phone Number:</strong> {profile?.PhoneNumber || 'N/A'}</p>
          <p>
            <strong>Address:</strong>{' '}
            {address ? (
              address.Street || address.Apt || address.City
                ? `${address.Street || ''}${address.Apt ? `, ${address.Apt}` : ''}, ${address.City || ''}`
                : 'No address'
            ) : (
              'No address'
            )}
          </p>
          <p>
            {address
              ? `${address.State || ''}${address.Zipcode ? `, ${address.Zipcode}` : ''}${
                  address.Country ? `, ${address.Country}` : ''
                }`.trim() || ''
              : ''}
          </p>
          <button onClick={handleEdit}>Edit Profile</button>
          <button onClick={handleAddressEdit}>Edit Address</button>
        </div>
      )}
    </div>
  );
}

export default ProfilePage;