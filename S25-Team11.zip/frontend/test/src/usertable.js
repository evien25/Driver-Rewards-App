import React, { useState, useEffect } from 'react';
import './css/about.css';

function UserTable() {
    const [error, setError] = useState(null);
    const [userData, setuserData] = useState([]);
    const [editingUserId, setEditingUserId] = useState(null);
    const [editedData, setEditedData] = useState({});
    const [roles, setRoles] = useState(['Admin', 'Driver', 'Sponsor User']); // Example roles

    const fetchUserDataFromDB = async () => {
        try {
            const response = await fetch(`${process.env.REACT_APP_API_URL}/api/usertable`);
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const data = await response.json();
            setuserData(data);
            setError(null);
        } catch (err) {
            console.error('Error fetching user data:', err);
            setError(err.message);
        }
    };

    useEffect(() => {
        fetchUserDataFromDB();
    }, []);

    const handleEdit = (user) => {
        setEditingUserId(user.UserID);
        setEditedData({
            UserID: user.UserID,
            FName: user.FName,
            LName: user.LName,
            Email: user.Email,
            PhoneNumber: user.PhoneNumber,
            Role: user.Role, 
        });
    };

    const handleInputChange = (event) => {
        const { name, value } = event.target;
        setEditedData(prevData => ({
            ...prevData,
            [name]: value,
        }));
    };

      const handleRoleChange = (event) => {
        setEditedData(prevData => ({
            ...prevData,
            Role: event.target.value,
        }));
    };

    const handleSave = async (userId) => {
      try {
        const profileResponse = await fetch(`${process.env.REACT_APP_API_URL}/api/profile`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            UserID: editedData.UserID,
            FName: editedData.FName,
            LName: editedData.LName,
            Email: editedData.Email,
            PhoneNumber: editedData.PhoneNumber,
          }),
        });

        if (!profileResponse.ok) {
          const errorData = await profileResponse.json();
          throw new Error(
            `HTTP error! status: ${profileResponse.status} - ${
              errorData.message || 'Failed to update profile'
            }`
          );
        }

        const roleResponse = await fetch(`${process.env.REACT_APP_API_URL}/api/user/role/${userId}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ role: editedData.Role }),
        });

        if (!roleResponse.ok) {
          const errorData = await roleResponse.json();
          throw new Error(
            `HTTP error! status: ${roleResponse.status} - ${
              errorData.message || 'Failed to update role'
            }`
          );
        }
        const roleData = await roleResponse.json();
        console.log(roleData.message);

        const profileData = await profileResponse.json();
        console.log('Profile updated:', profileData.message);
        setEditingUserId(null); // Exit edit mode
        fetchUserDataFromDB(); // Refresh user data
      } catch (err) {
        console.error('Error updating user:', err);
        setError(err.message);
      }
    };

    const handleCancel = () => {
        setEditingUserId(null);
        setEditedData({});
    };

    if (error) {
        return <div>Error: {error}</div>;
    }

    return (
        <div>
            <h2>Users</h2>
            <table>
                <thead>
                    <tr>
                        <th>UserID</th>
                        <th>Email</th>
                        <th>Username</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Phone Number</th>
                        <th>Role</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {userData.map((user) => (
                        <tr key={user.UserID}>
                            <td>{user.UserID}</td>
                            <td>
                                {editingUserId === user.UserID ? (
                                    <input
                                        type="email"
                                        name="Email"
                                        value={editedData.Email || ''}
                                        onChange={handleInputChange}
                                    />
                                ) : (
                                    user.Email
                                )}
                            </td>
                            <td>{user.Username}</td>
                            <td>
                                {editingUserId === user.UserID ? (
                                    <input
                                        type="text"
                                        name="FName"
                                        value={editedData.FName || ''}
                                        onChange={handleInputChange}
                                    />
                                ) : (
                                    user.FName
                                )}
                            </td>
                            <td>
                                {editingUserId === user.UserID ? (
                                    <input
                                        type="text"
                                        name="LName"
                                        value={editedData.LName || ''}
                                        onChange={handleInputChange}
                                    />
                                ) : (
                                    user.LName
                                )}
                            </td>
                            <td>
                                {editingUserId === user.UserID ? (
                                    <input
                                        type="text"
                                        name="PhoneNumber"
                                        value={editedData.PhoneNumber || ''}
                                        onChange={handleInputChange}
                                    />
                                ) : (
                                    user.PhoneNumber
                                )}
                            </td>
                             <td>
                                {editingUserId === user.UserID ? (
                                    <select
                                        name="Role"
                                        value={editedData.Role || ''}
                                        onChange={handleRoleChange}
                                    >
                                        {roles.map((role) => (
                                            <option key={role} value={role}>
                                                {role}
                                            </option>
                                        ))}
                                    </select>
                                ) : (
                                    user.Role
                                )}
                            </td>
                            <td>
                                {editingUserId === user.UserID ? (
                                    <>
                                        <button onClick={() => handleSave(user.UserID)}>Save</button>
                                        <button onClick={handleCancel}>Cancel</button>
                                    </>
                                ) : (
                                    <button onClick={() => handleEdit(user)}>Edit</button>
                                )}
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}

export default UserTable;
