import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import './css/driverdash.css';

function SpsDash({ onLogout }) {

  return (
    <div className="driver-dash-container">
      <div className="dashboard-content">
        <div className="button-grid">
          <Link to="/profile" className="grid-button">Profile</Link>
          <Link to="/Spsapp" className="grid-button">Sponsor Management</Link>
          <Link to="/SpsPoints" className="grid-button">Points Management</Link>
          <Link to="/reports" className="grid-button">Reports</Link>
          <Link to="/catalog" className="grid-button">Catalog Management</Link>
        </div>
      </div>
    </div>
  );
}

export default SpsDash;