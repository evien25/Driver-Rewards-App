import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import './css/driverdash.css';

function DriverDash({ onLogout }) {

  return (
    <div className="driver-dash-container">
      <div className="dashboard-content">
        <div className="button-grid">
          <Link to="/profile" className="grid-button">Profile</Link>
          <Link to="/SpsApp" className="grid-button">Application</Link>
          <Link to="/points" className="grid-button">Points</Link>
          <Link to="/cart" className="grid-button">Cart</Link>
          <Link to="/driver-catalog" className="grid-button">Catalog</Link>
          <Link to="/purchase-history" className="grid-button">Purchase History</Link>
        </div>
      </div>
    </div>
  );
}

export default DriverDash;