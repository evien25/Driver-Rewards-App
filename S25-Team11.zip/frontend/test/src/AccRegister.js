import React, { useState, useEffect } from 'react';
import './css/accregister.css'; // Import the CSS file

function AccRegister() {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [email, setEmail] = useState('');
    const [FName, setFName] = useState('');
    const [LName, setLName] = useState('');
    const [phonenumber, setPhonenumber] = useState('');
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');
        setLoading(true);

        try {
            const response = await fetch(`${process.env.REACT_APP_API_URL}/api/AccRegister`, { // Flask route
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ email, username, password, FName, LName, phonenumber }), // Send username/password in JSON
            });

            if (!response.ok) {  // Check for HTTP errors (400, 500, etc.)
                const errorData = await response.json(); // Try to parse error message from Flask
                throw new Error(errorData.message || 'Login failed'); // Throw the error to be caught
            }

            const data = await response.json(); // Assuming Flask returns JSON with a token
            if (data.success) {
                localStorage.setItem('token', data.token); // Save the token to local storage
                window.location.href = '/profile'; // Navigate to profile
            } else {
                setError(data.message || 'Login failed'); // Display Flask-provided message or generic message
            }

        } catch (err) {
            setError(err.message || 'An error occurred. Please try again later.');
            console.error("Login Error:", err);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div>
            <div className="ARForm-container">
                <h2>Create an Account</h2>
                {error && <div className="error">{error}</div>} {/* Added error display */}
                <form onSubmit={handleSubmit}>
                    <div className="ARForm-group">
                        <label htmlFor="Fname">First Name</label>
                        <input
                            type="text"
                            id="Fname"
                            name="Fname"
                            required
                            placeholder="Enter your first name"
                            value={FName}
                            onChange={(e) => setFName(e.target.value)}
                        />
                    </div>
                    <div className="ARForm-group">
                        <label htmlFor="Lname">Last Name</label>
                        <input
                            type="text"
                            id="Lname"
                            name="Lname"
                            required
                            placeholder="Enter your last name"
                            value={LName}
                            onChange={(e) => setLName(e.target.value)}
                        />
                    </div>
                    <div className="ARForm-group">
                        <label htmlFor="email">Email Address</label>
                        <input
                            type="email"
                            id="email"
                            name="email"
                            required
                            placeholder="Enter your email address"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                        />
                    </div>
                    <div className="ARForm-group">
                        <label htmlFor="Phonenumber">Phone Number</label>
                        <input
                            type="text"
                            id="Phonenumber"
                            name="Phonenumber"
                            required
                            placeholder="Enter your phone number"
                            value={phonenumber}
                            onChange={(e) => setPhonenumber(e.target.value)}
                        />
                    </div>
                    <div className="ARForm-group">
                        <label htmlFor="Username">Username</label>
                        <input
                            type="text"
                            id="Username"
                            name="Username"
                            required
                            placeholder="Enter your username"
                            value={username}
                            onChange={(e) => setUsername(e.target.value)}
                        />
                    </div>
                    <div className="ARForm-group">
                        <label htmlFor="password">Password</label>
                        <input
                            type="password"
                            id="password"
                            name="password"
                            required
                            placeholder="Enter your password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                        />
                    </div>
                    <button type="submit" disabled={loading} name="loginButton">
                        {loading ? 'Creating Account...' : 'Create Account'}
                    </button>
                </form>
                <div className="form-footer">
                    <p>Already have an account? <a href="/login">Login here</a>.</p>
                </div>
            </div>
        </div>
    );
}

export default AccRegister;