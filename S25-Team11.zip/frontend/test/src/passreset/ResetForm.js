import React, { useState } from 'react';
import axios from 'axios';
import './passres.css';

function PasswordResetForm() {
  const [token, setToken] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [message, setMessage] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(`${process.env.REACT_APP_API_URL}/api/reset-password`, {
        token,
        newPassword
      });
      setMessage(response.data.message);
    } catch (error) {
      setMessage(error.response?.data.error || 'An error occurred');
    }
  };

  return (
    <div class="password-forms-wrapper"> 
      <div class="set-password-form-container">
        <h2>Set New Password</h2>
        <form onSubmit={handleSubmit}>
          <input
            type="text"
            value={token}
            onChange={(e) => setToken(e.target.value)}
            placeholder="Enter reset token"
            required
          />
          <input
            type="password"
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
            placeholder="Enter new password"
            required
          />
          <button type="submit">Reset Password</button>
        </form>
        {message && <p>{message}</p>}
      </div>
    </div>
  );
}

export default PasswordResetForm;