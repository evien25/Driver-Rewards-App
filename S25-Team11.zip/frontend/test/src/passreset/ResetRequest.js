import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './passres.css';

function PasswordResetRequest() {
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(`${process.env.REACT_APP_API_URL}/api/request-password-reset`, { email });
      setMessage(response.data.message);
      // Navigate to reset form after a delay
      setTimeout(() => navigate('/reset-password'), 2000);
    } catch (error) {
      setMessage(error.response?.data.error || 'An error occurred');
    }
  };

  return (
    <div class="password-forms-wrapper"> 
      <div class="request-reset-form-container">
      <h2>Reset Password</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Enter your email"
          required
        />
        <button type="submit">Request Reset</button>
      </form>
      {message && <p>{message}</p>}
    </div>
  </div>
  );
}

export default PasswordResetRequest;