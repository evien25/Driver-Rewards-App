#/bin/bash
cd test & yarn start
